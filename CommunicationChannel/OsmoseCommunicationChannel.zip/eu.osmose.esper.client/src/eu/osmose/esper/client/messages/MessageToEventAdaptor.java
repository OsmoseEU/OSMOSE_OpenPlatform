package eu.osmose.esper.client.messages;

import java.io.IOException;
import java.util.logging.Logger;

import com.espertech.esper.client.EPServiceProvider;
import com.espertech.esper.client.EPServiceProviderManager;
import com.rabbitmq.client.AMQP.BasicProperties;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Envelope;

import eu.osmose.cm.messages.AMessageConsumer;


public class MessageToEventAdaptor extends AMessageConsumer {
	
	Logger logger = Logger.getLogger(MessageToEventAdaptor.class.getName());

	public MessageToEventAdaptor(Channel channel) {
		super(channel);
	}

	@Override
	public void handleDelivery(String consumerTag, Envelope envelope,
			BasicProperties properties, byte[] body) throws IOException {
		String message = new String(body, getMessageEncoding());
		logger.info("[x] "+MessageToEventAdaptor.class.getSimpleName()+": Received '" + message + "'");
		EPServiceProvider epService = EPServiceProviderManager.getDefaultProvider();
		epService.getEPRuntime().sendEvent(new MessageToEventEvent(message));
	}
}
