package eu.osmose.esper.client.messages;

public class MessageToEventEvent implements IMessageEvent{

	private String content;
	private String header;
	private String message;
	

	public MessageToEventEvent() {
	}
	
	public MessageToEventEvent(String message) {
		this.message = message;
		if (message == null)
			return;
		String[] messageSplit = message.split(HEADER_SEPARATOR);
		if (messageSplit[0] != null)
			this.header = messageSplit[0];
		if (messageSplit[1] != null)
			this.content = messageSplit[1];
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getHeader() {
		return header;
	}

	public void setHeader(String header) {
		this.header = header;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}
	
}