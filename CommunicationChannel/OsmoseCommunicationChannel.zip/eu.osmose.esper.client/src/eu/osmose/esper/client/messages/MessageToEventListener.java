package eu.osmose.esper.client.messages;

import java.util.Map;

import com.espertech.esper.client.EPServiceProvider;
import com.espertech.esper.client.EPServiceProviderManager;
import com.espertech.esper.client.EventBean;
import com.espertech.esper.client.UpdateListener;
import com.espertech.esper.event.map.MapEventBean;

public class MessageToEventListener implements UpdateListener {

	private String message;
	
	public MessageToEventListener(String message) {
		this.message = message;
	}

	@Override
	public void update(EventBean[] newEvents, EventBean[] oldEvents) {
		for(EventBean newEvent:newEvents) {
			if(newEvent.getUnderlying() instanceof MessageToEventEvent) {
				EventToMessageEvent newTypedEvent = new EventToMessageEvent(message);
				EPServiceProvider epService = EPServiceProviderManager.getDefaultProvider();
				epService.getEPRuntime().sendEvent(newTypedEvent);
			} else if (newEvent instanceof MapEventBean) {
				EventToMessageEvent newTypedEvent = new EventToMessageEvent(message);
				EPServiceProvider epService = EPServiceProviderManager.getDefaultProvider();
				epService.getEPRuntime().sendEvent(newTypedEvent);
			}
		}
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
}
