package eu.osmose.esper.client.messages;

public class EventToMessageEvent implements IMessageEvent {
	private String content;
	private String header;
	private String message;
	
	public EventToMessageEvent(String message) {
		if (message==null)
			return;
		else
			this.message = message;
		if(message.contains(IMessageEvent.HEADER_SEPARATOR)) {
			this.header = message.split(IMessageEvent.HEADER_SEPARATOR)[0];
			this.content = message.split(IMessageEvent.HEADER_SEPARATOR)[1];
		}
	}

	public EventToMessageEvent(String header, String content) {
		this.header=header;
		this.content=content;
		this.message = header+IMessageEvent.HEADER_SEPARATOR+content;
	}
	
	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	@Override
	public String getHeader() {
		return header;
	}
	
	public void setHeader(String header) {
		this.header = header;
	}
	
	public String getMessage() {
		return message;
	}
}
