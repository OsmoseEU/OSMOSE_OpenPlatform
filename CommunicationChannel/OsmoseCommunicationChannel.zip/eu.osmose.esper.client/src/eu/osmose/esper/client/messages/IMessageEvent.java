package eu.osmose.esper.client.messages;

public interface IMessageEvent {
	
	public static final String MESSAGE_PROPERTY_SEPARATOR = ";";
	public static final String PROPERTY_ALLOCATION_OPERATOR =":";
	public static final String HEADER_SEPARATOR = "##";
	
	public String getContent();
	public String getHeader();
	public String getMessage();
}
