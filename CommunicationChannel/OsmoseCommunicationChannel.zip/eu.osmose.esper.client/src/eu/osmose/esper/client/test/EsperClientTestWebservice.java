package eu.osmose.esper.client.test;

import java.sql.Timestamp;
import java.util.Date;

import com.espertech.esper.client.EPServiceProvider;
import com.espertech.esper.client.EPServiceProviderManager;

import eu.osmose.cm.messages.MessageEndpoint;
import eu.osmose.cm.messages.types.AMessage;
import eu.osmose.esper.client.activation.EsperClientActivator;
import eu.osmose.esper.client.messages.EventToMessageEvent;

public class EsperClientTestWebservice {

	public EsperClientTestWebservice() {
		
	}
	
	public void testSendSensorMessage(String temperature, String humidity, String pressure, String axelX, String axelY, String gas, String panic) {
		MessageEndpoint messageEndpoint = new MessageEndpoint();
		messageEndpoint.getMessagePublisher().publishMessage("SensorMessage##"+"timestamp:"+new Timestamp(new Date().getTime()).toString()+";temperature:"+temperature+";humidity:"+humidity+";pressure:"+pressure+";axelX:"+axelX+";axelY:"+axelY+";gas:"+gas+";panic:"+panic);
	}
	
	public void testSendSensorEvent(String message) {
		EPServiceProvider epService = EPServiceProviderManager.getDefaultProvider();
		epService.getEPRuntime().sendEvent(new EventToMessageEvent("TEST", message));
	}
	
	
	/**
	 * Configure behavior of events that come from messages
	 * 
	 * @param epl
	 */
	public void addEPLStatement(String epl, String header, String content) {
		EsperClientActivator.addEPLStatement(epl, header+AMessage.MESSAGE_SEPARATOR+content);
	}
	
	
}
