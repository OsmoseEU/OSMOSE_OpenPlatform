package eu.osmose.esper.client.activation;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

import com.espertech.esper.client.EPServiceProvider;
import com.espertech.esper.client.EPServiceProviderManager;
import com.espertech.esper.client.EPStatement;

import eu.osmose.cm.messages.MessageEndpoint;
import eu.osmose.esper.client.messages.EventToMessageListener;
import eu.osmose.esper.client.messages.MessageToEventAdaptor;
import eu.osmose.esper.client.messages.MessageToEventListener;

@WebListener
public class EsperClientActivator implements ServletContextListener {

	private MessageEndpoint messageEndpoint;
	
	public EsperClientActivator() {
		messageEndpoint = new MessageEndpoint();
		EPServiceProvider epService = EPServiceProviderManager.getDefaultProvider();
		epService.getEPAdministrator().getConfiguration().addPlugInSingleRowFunction("attribute", "eu.osmose.esper.client.messages.EventUtil", "getEventAttribute");
	}

	@Override
	public void contextDestroyed(ServletContextEvent arg0) {
		// not implemented
	}

	@Override
	public void contextInitialized(ServletContextEvent arg0) {
		initMessageToEventBehaviour();
		initEventToMessageBehaviour();
	}

	private void initEventToMessageBehaviour() {
		EPServiceProvider epService = EPServiceProviderManager.getDefaultProvider();
		String expression = "select * from eu.osmose.esper.client.messages.EventToMessageEvent";
		EPStatement statement = epService.getEPAdministrator().createEPL(expression);
		statement.addListener(new EventToMessageListener());
	}
	
	private void initMessageToEventBehaviour() {
		messageEndpoint.getCEPMessageSubscriber().addMessageConsumer(
				new MessageToEventAdaptor(messageEndpoint.getMessageChannel()));
	}
	
	public static void addEPLStatement(String epl, String message) {
		EPServiceProvider epService = EPServiceProviderManager.getDefaultProvider();
		
		// select attribute(content, 'temperature') as temp from eu.osmose.esper.client.messages.MessageToEventEvent
		String expression = epl;
		EPStatement statement = epService.getEPAdministrator().createEPL(expression);
		statement.addListener(new MessageToEventListener(message));
	}

}
