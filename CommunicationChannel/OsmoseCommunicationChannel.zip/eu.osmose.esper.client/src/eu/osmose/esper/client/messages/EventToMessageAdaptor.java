package eu.osmose.esper.client.messages;

import eu.osmose.cm.messages.AMessageProducer;
import eu.osmose.cm.messages.MessageEndpoint;
import eu.osmose.cm.messages.types.IMessage;

public class EventToMessageAdaptor extends AMessageProducer {

	public EventToMessageAdaptor() {
		super(new MessageEndpoint().getMessagePublisher());
	}
}
