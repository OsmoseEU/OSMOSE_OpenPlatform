package eu.osmose.esper.client.messages;

public class EventUtil {
	public static String getEventAttribute(String content, String attribute) {
		if(!content.contains(attribute))
			return "";
		else {
			// TODO: stabilization
			content = content.substring(content.indexOf(attribute+":"));
			return content.substring(content.indexOf(":")+1, content.indexOf(";"));
		}
	}
}
