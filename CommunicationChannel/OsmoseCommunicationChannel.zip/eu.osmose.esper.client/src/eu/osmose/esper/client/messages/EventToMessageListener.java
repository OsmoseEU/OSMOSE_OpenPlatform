package eu.osmose.esper.client.messages;

import com.espertech.esper.client.EventBean;
import com.espertech.esper.client.UpdateListener;

public class EventToMessageListener implements UpdateListener {

	private EventToMessageAdaptor messageProducer = new EventToMessageAdaptor();
	private String message;

	public EventToMessageListener() {
	}
	
	public EventToMessageListener(String message) {
		this.message = message;
	}

	@Override
	public void update(EventBean[] newEvents, EventBean[] oldEvents) {
		for (EventBean eventBean : newEvents) {
			if (eventBean.getUnderlying() instanceof EventToMessageEvent) {
				EventToMessageEvent eventToMessageEvent = (EventToMessageEvent) eventBean.getUnderlying();
				if(this.message==null)
					this.message = eventToMessageEvent.getMessage();
				messageProducer.publishMessage(eventToMessageEvent.getMessage());
			}
		}
	}
}
