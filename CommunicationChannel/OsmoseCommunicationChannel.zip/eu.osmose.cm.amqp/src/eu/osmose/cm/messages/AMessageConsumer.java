package eu.osmose.cm.messages;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.DefaultConsumer;

import eu.osmose.cm.messages.properties.IMessagePropertyAccess;
import eu.osmose.cm.messages.properties.MessagePropertyAccessFactory;
import eu.osmose.cm.messages.properties.MessagePropertyType;

public abstract class AMessageConsumer extends DefaultConsumer {

	public AMessageConsumer(Channel channel) {
		super(channel);
	}

	protected String getMessageEncoding() {
		return getMessageEncodingPropertyAccess().getMessagePropertyValue();
	}

	private IMessagePropertyAccess getMessageEncodingPropertyAccess() {
		return getMessagePropertyAccessFactory().getMessagePropertyAccess(
				MessagePropertyType.MESSAGE_ENCODING);
	}

	private MessagePropertyAccessFactory getMessagePropertyAccessFactory() {
		return MessagePropertyAccessFactory.getInstance();
	}

}
