package eu.osmose.cm.messages.types;

public class ContextManagerResponseIndividualMessage extends AMessage {
	private String knowledgeLinkId;
	private String ontology;
	private String ontologyClass;
	private String allIndividualsAndValues;

	public ContextManagerResponseIndividualMessage(String knowledgeLinkId, String ontology, String ontologyClass,
			String allIndividualsAndValues) {
		super();
		this.knowledgeLinkId = knowledgeLinkId;
		this.ontology = ontology;
		this.ontologyClass = ontologyClass;
		this.allIndividualsAndValues = allIndividualsAndValues;
	}

	public String getKnowledgeLinkId() {
		return knowledgeLinkId;
	}

	public void setKnowledgeLinkId(String knowledgeLinkId) {
		this.knowledgeLinkId = knowledgeLinkId;
	}

	public String getOntology() {
		return ontology;
	}

	public void setOntology(String ontology) {
		this.ontology = ontology;
	}

	public String getOntologyClass() {
		return ontologyClass;
	}

	public void setOntologyClass(String ontologyClass) {
		this.ontologyClass = ontologyClass;
	}

	public String getAllIndividualsAndValues() {
		return allIndividualsAndValues;
	}

	public void setAllIndividualsAndValues(String allIndividualsAndValues) {
		this.allIndividualsAndValues = allIndividualsAndValues;
	}

	@Override
	public String getHeader() {
		return ContextManagerResponseIndividualMessage.class.getSimpleName();
	}

	@Override
	public String getContent() {
		return "knowledgeLinkId="+knowledgeLinkId+AMessage.MESSAGE_SEPARATOR+"ontology="+ontology+AMessage.MESSAGE_SEPARATOR+"ontologyClass="+ontologyClass+AMessage.MESSAGE_SEPARATOR+"Individuals="+allIndividualsAndValues;
	}

}
