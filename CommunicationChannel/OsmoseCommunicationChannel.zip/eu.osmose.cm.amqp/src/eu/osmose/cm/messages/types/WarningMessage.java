package eu.osmose.cm.messages.types;

public class WarningMessage extends AMessage {

	String content = "";
	String userInput = "";
	
	public WarningMessage(String userInput) {
		this.userInput = userInput;
		this.content = "<event>"
		+ "    <domain> Automotive </domain>"
		+ "    <worldID> Real World </worldID>"
		+ "    <eventType> Warning </eventType>"
		+ "    <timeStamp> Time </timeStamp>"
		+ "    <eventResourceURI>http://www.semanticweb.org/catarina/ontologies/2015/2/untitled-ontology-7#Tool</eventResourceURI>"
		+ "    <body>" + userInput+ "</body>"
				+ "    <dataURI> </dataURI>"
				+ "</event>";
	}


	@Override
	public String getHeader() {
		return "WARNING";
	}

	@Override
	public String getContent() {
		return content;
	}

}
