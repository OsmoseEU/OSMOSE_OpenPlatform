package eu.osmose.cm.messages.properties;

public interface IMessagePropertyAccess {
	public String getMessagePropertyValue();
}
