package eu.osmose.cm.messages;

import java.io.IOException;
import java.util.concurrent.TimeoutException;
import java.util.logging.Logger;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

public class MessageEndpoint extends AMessagePropertyConsumer {

	Logger logger = Logger.getLogger(MessageEndpoint.class.getName());

	private Channel channel;

	private MessageSubscriber cepMessageSubscriber;
	private MessageSubscriber cmMessageSubscriber;
	private MessageSubscriber bpmsMessageSubscriber;
	private MessagePublisher messagePublisher;

	private String cm_queue;
	private String cep_queue;
	private String bpms_queue;

	private String exchange;
	private String rw_exchange;
	private String dw_exchange;
	private String vw_exchange;

	public MessageEndpoint() {
		init();
	}

	private void init() {
		ConnectionFactory factory = new ConnectionFactory();
		factory.setHost(getHost());
		Connection connection = null;
		channel = null;
		exchange = getExchange();
		rw_exchange = getRWExchange();
		dw_exchange = getDWExchange();
		vw_exchange = getVWExchange();
		cm_queue = getCMQueue();
		cep_queue = getCEPQueue();
		bpms_queue = getBPMSQueue();

		try {
			try {
				connection = factory.newConnection();
			} catch (TimeoutException e) {
				e.printStackTrace();
			}
			channel = connection.createChannel();
			channel.exchangeDeclare(exchange, "fanout", true);
			channel.exchangeDeclare(rw_exchange, "fanout", true);
			channel.exchangeDeclare(dw_exchange, "fanout", true);
			channel.exchangeDeclare(vw_exchange, "fanout", true);
			channel.queueDeclare(cm_queue, true, false, false, null);
			channel.queueBind(cm_queue, exchange, "");
			channel.queueDeclare(cep_queue, true, false, false, null);
			channel.queueBind(cep_queue, exchange, "");
			channel.queueDeclare(bpms_queue, true, false, false, null);
			channel.queueBind(bpms_queue, exchange, "");
		} catch (IOException e) {
			logger.info("Could not initialize message queue. \n " + e);
		}
		logger.info("Queue initialization finished successfully. ");

		cmMessageSubscriber = new MessageSubscriber(cm_queue, channel);
		cepMessageSubscriber = new MessageSubscriber(cep_queue, channel);
		bpmsMessageSubscriber = new MessageSubscriber(bpms_queue, channel);
		messagePublisher = new MessagePublisher(channel);
	}

	public Channel getMessageChannel() {
		return channel;
	}

	public String getCMMessageQueue() {
		return cm_queue;
	}

	public String getCEPMessageQueue() {
		return cep_queue;
	}

	public MessageSubscriber getCMMessageSubscriber() {
		return cmMessageSubscriber;
	}

	public MessageSubscriber getCEPMessageSubscriber() {
		return cepMessageSubscriber;
	}

	public MessageSubscriber getBPMSMessageSubscriber() {
		return bpmsMessageSubscriber;
	}

	public MessagePublisher getMessagePublisher() {
		return messagePublisher;
	}
	
	public MessageSubscriber getVWMessageSubscriber() {
		try {
			String queueName = channel.queueDeclare().getQueue();
			channel.queueBind(queueName, vw_exchange, "");
			return new MessageSubscriber(queueName, channel);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public MessageSubscriber getDWMessageSubscriber() {
		try {
			String queueName = channel.queueDeclare().getQueue();
			channel.queueBind(queueName, dw_exchange, "");
			return new MessageSubscriber(queueName, channel);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public MessageSubscriber getRWMessageSubscriber() {
		try {
			String queueName = channel.queueDeclare().getQueue();
			channel.queueBind(queueName, rw_exchange, "");
			return new MessageSubscriber(queueName, channel);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
}
