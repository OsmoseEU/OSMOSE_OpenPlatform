package eu.osmose.cm.messages.properties;

public enum MessagePropertyType {
	HOST, EXCHANGE, CM_QUEUE, CEP_QUEUE, BPMS_QUEUE, MESSAGE_ENCODING, RW_EXCHANGE, DW_EXCHANGE, VW_EXCHANGE;
	

	public String getPropertyKey() {
		return this.name();
	}
}
