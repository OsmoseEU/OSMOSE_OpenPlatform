package eu.osmose.cm.messages;

import java.io.IOException;
import java.io.UnsupportedEncodingException;

import java.util.logging.Logger;

import com.rabbitmq.client.Channel;

import eu.osmose.cm.messages.types.IMessage;

public class MessagePublisher extends AMessagePropertyConsumer {

	Logger logger = Logger.getLogger(MessagePublisher.class.getName());

	private Channel channel;

	public MessagePublisher(Channel channel) {
		this.channel = channel;
	}

	public void publishMessage(IMessage message) {
		this.publishMessage(message.getMessage());
	}

	public void publishMessage(String message) {
		try {
			channel.basicPublish(getExchange(), "", null,
					getEncodedMessage(message));
		} catch (IOException e) {
			logger.severe("Errors encoutered during message sending. \n " + e);
		}
		logger.info(" [x] Sent '" + message + "'");

	}
	
	public void publishDWMessage(String message) {
		try {
			channel.basicPublish(getDWExchange(), "", null,
					getEncodedMessage(message));
		} catch (IOException e) {
			logger.severe("Errors encoutered during message sending. \n " + e);
		}
		logger.info(" [x] Sent '" + message + "' to the Digital World");

	}
	
	public void publishRWMessage(String message) {
		try {
			channel.basicPublish(getRWExchange(), "", null,
					getEncodedMessage(message));
		} catch (IOException e) {
			logger.severe("Errors encoutered during message sending. \n " + e);
		}
		logger.info(" [x] Sent '" + message + "' to the Real World");

	}
	
	public void publishVWMessage(String message) {
		try {
			channel.basicPublish(getVWExchange(), "", null,
					getEncodedMessage(message));
		} catch (IOException e) {
			logger.severe("Errors encoutered during message sending. \n " + e);
		}
		logger.info(" [x] Sent '" + message + "' to the Virtual World");

	}

	private byte[] getEncodedMessage(String message) {
		try {
			return message.getBytes(getMessageEncoding());
		} catch (UnsupportedEncodingException e) {
			logger.severe("Encoding not supported! \n " + e);
		}
		return null;
	}

}
