package eu.osmose.rabbit.mq.client;

import java.io.IOException;
import java.util.logging.Logger;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Response;

import eu.osmose.rabbit.mq.messages.OpenPlatformDemonstratorMessageProducer;
import eu.osmose.rabbit.mq.messages.TemperatureMessage;

@Path("message")
public class RabbitMqWebService {
	Logger logger = Logger.getLogger(RabbitMqWebService.class.getName());

	@GET
	@Path("/temperature/{toolId}/{temp}")
	public Response sendTemperatureMessage(@PathParam("toolId") String toolId, @PathParam("temp") String value) {
		OpenPlatformDemonstratorMessageProducer messageProducer = new OpenPlatformDemonstratorMessageProducer();
		TemperatureMessage message;
		try {
			message = messageProducer.publishTemperatureMessage(toolId, value);
			return Response.status(Response.Status.OK).entity(message.getMessage()).build();
		} catch (IOException e) {
			logger.severe("ERROR! See Stacktrace:\n" + e.getStackTrace());
			return Response.status(Response.Status.BAD_REQUEST).entity("Error during message publication.").build();
		}
		
	}
}
