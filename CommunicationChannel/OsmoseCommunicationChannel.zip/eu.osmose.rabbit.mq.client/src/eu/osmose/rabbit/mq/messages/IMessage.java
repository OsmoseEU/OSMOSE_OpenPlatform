package eu.osmose.rabbit.mq.messages;

public interface IMessage {
	public String getContent();
	public String getHeader();
	public String getMessage();
}
