package eu.osmose.rabbit.mq.messages;

public abstract class AMessage implements IMessage {
	
	public static final String MESSAGE_SEPARATOR = "##";
	
	@Override
	public final String getMessage() {
		return getHeader() + MESSAGE_SEPARATOR + getContent();
	}
	
	@Override
	public abstract String getHeader();
	
	@Override
	public abstract String getContent();
}
