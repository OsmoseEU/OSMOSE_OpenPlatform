package eu.osmose.rabbit.mq.messages;

import java.io.IOException;
import java.util.concurrent.TimeoutException;
import java.util.logging.Logger;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

public class MessageEndpoint {

	Logger logger = Logger.getLogger(MessageEndpoint.class.getName());

	public static final String HOST = "localhost";
	public static final String QUEUE = "QUEUE";
	public static final String EXCHANGE = "EXCHANGE";
	
	public static final String RW_EXCHANGE = "REALWORLD_OPEN_DEMONSTRATOR";
	public static final String RW_QUEUE = "REALWORLDQUEUE_OPEN_DEMONSTRATOR";
	
	private Channel channel;

	private MessagePublisher messagePublisher;

	private MessageSubscriber messageSubscriber;

	private MessageSubscriber realWorldMessageSubscriber;

	public MessageEndpoint() {
		init();
	}

	private void init() {
		ConnectionFactory factory = new ConnectionFactory();
		factory.setHost(HOST);
		Connection connection = null;
		channel = null;

		try {
			try {
				connection = factory.newConnection();
			} catch (TimeoutException e) {
				e.printStackTrace();
			}
			channel = connection.createChannel();
			channel.exchangeDeclare(EXCHANGE, "fanout", true);
			channel.exchangeDeclare(RW_EXCHANGE, "fanout", true);
			channel.queueDeclare(QUEUE, true, false, false, null);
			channel.queueBind(QUEUE, EXCHANGE, "");
			channel.queueDeclare(RW_QUEUE, true, false, false, null);
			channel.queueBind(RW_QUEUE, RW_EXCHANGE, "");
		} catch (IOException e) {
			logger.info("Could not initialize message queue. \n " + e);
		}
		logger.info("Queue initialization finished successfully. ");

		messageSubscriber = new MessageSubscriber(QUEUE, channel);
		realWorldMessageSubscriber = new MessageSubscriber(RW_QUEUE, channel);
		messagePublisher = new MessagePublisher(channel);
	}

	public Channel getMessageChannel() {
		return channel;
	}

	public MessagePublisher getMessagePublisher() {
		return messagePublisher;
	}
	
	public MessageSubscriber getMessageSubscriber() {
		return messageSubscriber;
	}
	
	public MessageSubscriber getRealWorldMessageSubscriber() {
		return realWorldMessageSubscriber;
	}
}
