package eu.osmose.rabbit.mq.messages;

import java.io.IOException;

public class OpenPlatformDemonstratorMessageProducer{
	
	private MessagePublisher messagePublisher;
	
	public OpenPlatformDemonstratorMessageProducer() {
		this.messagePublisher = new MessageEndpoint().getMessagePublisher();
	}
	
	public TemperatureMessage publishTemperatureMessage(String toolId, String value) throws IOException {
		TemperatureMessage message = new TemperatureMessage(toolId, value);
		this.publishRWMessage(message);
		return message;
	}
	
	public void publishRWMessage(IMessage message) throws IOException {
		messagePublisher.publishMessage(MessageEndpoint.RW_EXCHANGE, message);
	}
}
