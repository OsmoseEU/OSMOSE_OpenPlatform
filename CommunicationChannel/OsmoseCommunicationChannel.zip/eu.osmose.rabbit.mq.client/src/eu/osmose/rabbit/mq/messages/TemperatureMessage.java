package eu.osmose.rabbit.mq.messages;

public class TemperatureMessage extends AMessage {
	
	private String toolId;
	private String temperature;

	public TemperatureMessage(String toolId, String temperature) {
		super();
		this.toolId = toolId;
		this.temperature = temperature;
	}
	
	@Override
	public String getHeader() {
		return "TEMPERATUREMESSAGE";
	}

	@Override
	public String getContent() {
		return "toolId="+toolId+";"+"temperature="+temperature;
	}

}
