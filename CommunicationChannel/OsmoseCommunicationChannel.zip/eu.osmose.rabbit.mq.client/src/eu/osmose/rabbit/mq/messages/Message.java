package eu.osmose.rabbit.mq.messages;

public class Message extends AMessage {

	private String header;
	private String content;
	
	public Message(String header, String content) {
		this.header = header;
		this.content = content;
	}
	
	@Override
	public String getHeader() {
		return header;
	}

	@Override
	public String getContent() {
		return content;
	}

}
