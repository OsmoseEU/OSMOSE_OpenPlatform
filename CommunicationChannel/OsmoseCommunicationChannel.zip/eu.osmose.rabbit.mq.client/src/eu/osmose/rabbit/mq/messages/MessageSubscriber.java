package eu.osmose.rabbit.mq.messages;

import java.io.IOException;

import java.util.logging.Logger;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.DefaultConsumer;

public class MessageSubscriber {

	Logger logger = Logger.getLogger(MessageSubscriber.class.getName());

	private Channel channel;
	private String queue;

	public MessageSubscriber(String queue, Channel channel) {
		this.queue = queue;
		this.channel = channel;
	}

	public boolean addMessageConsumer(DefaultConsumer messageConsumer) {
		try {
			channel.basicConsume(queue, true, messageConsumer);
			logger.info("Consumer initialization finished successfully. Waiting for messages on queue: "
					+ queue);
			return true;
		} catch (IOException e) {
			logger.severe("Could not initialize message consumer. \n " + e);
			return false;
		}
	}

}
