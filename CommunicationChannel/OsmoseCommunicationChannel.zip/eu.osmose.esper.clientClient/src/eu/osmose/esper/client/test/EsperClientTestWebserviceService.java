/**
 * EsperClientTestWebserviceService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package eu.osmose.esper.client.test;

public interface EsperClientTestWebserviceService extends javax.xml.rpc.Service {
    public java.lang.String getEsperClientTestWebserviceAddress();

    public eu.osmose.esper.client.test.EsperClientTestWebservice getEsperClientTestWebservice() throws javax.xml.rpc.ServiceException;

    public eu.osmose.esper.client.test.EsperClientTestWebservice getEsperClientTestWebservice(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
