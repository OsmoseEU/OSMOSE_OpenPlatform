/**
 * EsperClientTestWebservice.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package eu.osmose.esper.client.test;

public interface EsperClientTestWebservice extends java.rmi.Remote {
    public void testSendSensorMessage(java.lang.String temperature, java.lang.String humidity, java.lang.String pressure, java.lang.String axelX, java.lang.String axelY, java.lang.String gas, java.lang.String panic) throws java.rmi.RemoteException;
    public void testSendSensorEvent(java.lang.String message) throws java.rmi.RemoteException;
    public void addEPLStatement(java.lang.String epl, java.lang.String header, java.lang.String content) throws java.rmi.RemoteException;
}
