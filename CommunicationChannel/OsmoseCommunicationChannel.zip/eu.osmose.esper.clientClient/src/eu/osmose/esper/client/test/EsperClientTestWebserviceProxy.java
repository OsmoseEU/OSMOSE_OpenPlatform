package eu.osmose.esper.client.test;

public class EsperClientTestWebserviceProxy implements eu.osmose.esper.client.test.EsperClientTestWebservice {
  private String _endpoint = null;
  private eu.osmose.esper.client.test.EsperClientTestWebservice esperClientTestWebservice = null;
  
  public EsperClientTestWebserviceProxy() {
    _initEsperClientTestWebserviceProxy();
  }
  
  public EsperClientTestWebserviceProxy(String endpoint) {
    _endpoint = endpoint;
    _initEsperClientTestWebserviceProxy();
  }
  
  private void _initEsperClientTestWebserviceProxy() {
    try {
      esperClientTestWebservice = (new eu.osmose.esper.client.test.EsperClientTestWebserviceServiceLocator()).getEsperClientTestWebservice();
      if (esperClientTestWebservice != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)esperClientTestWebservice)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)esperClientTestWebservice)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (esperClientTestWebservice != null)
      ((javax.xml.rpc.Stub)esperClientTestWebservice)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public eu.osmose.esper.client.test.EsperClientTestWebservice getEsperClientTestWebservice() {
    if (esperClientTestWebservice == null)
      _initEsperClientTestWebserviceProxy();
    return esperClientTestWebservice;
  }
  
  public void testSendSensorMessage(java.lang.String temperature, java.lang.String humidity, java.lang.String pressure, java.lang.String axelX, java.lang.String axelY, java.lang.String gas, java.lang.String panic) throws java.rmi.RemoteException{
    if (esperClientTestWebservice == null)
      _initEsperClientTestWebserviceProxy();
    esperClientTestWebservice.testSendSensorMessage(temperature, humidity, pressure, axelX, axelY, gas, panic);
  }
  
  public void testSendSensorEvent(java.lang.String message) throws java.rmi.RemoteException{
    if (esperClientTestWebservice == null)
      _initEsperClientTestWebserviceProxy();
    esperClientTestWebservice.testSendSensorEvent(message);
  }
  
  public void addEPLStatement(java.lang.String epl, java.lang.String header, java.lang.String content) throws java.rmi.RemoteException{
    if (esperClientTestWebservice == null)
      _initEsperClientTestWebserviceProxy();
    esperClientTestWebservice.addEPLStatement(epl, header, content);
  }
  
  
}