package eu.osmose.cm.messages.properties;

public class MessagePropertyAccess implements IMessagePropertyAccess {

	private String messagePropertyValue;

	public MessagePropertyAccess(String messagePropertyValue) {
		this.messagePropertyValue = messagePropertyValue;
	}

	@Override
	public String getMessagePropertyValue() {
		return this.messagePropertyValue;
	}

}
