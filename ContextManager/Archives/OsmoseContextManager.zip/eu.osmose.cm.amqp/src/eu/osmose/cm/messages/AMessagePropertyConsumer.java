package eu.osmose.cm.messages;

import eu.osmose.cm.messages.properties.IMessagePropertyAccess;
import eu.osmose.cm.messages.properties.MessagePropertyAccessFactory;
import eu.osmose.cm.messages.properties.MessagePropertyType;

public abstract class AMessagePropertyConsumer {
	
	protected String getMessageEncoding() {
		IMessagePropertyAccess messagePropertyAccess = getMessagePropertyAccess(MessagePropertyType.MESSAGE_ENCODING);
		return messagePropertyAccess.getMessagePropertyValue();
	}
	
	protected String getHost() {
		IMessagePropertyAccess messagePropertyAccess = getMessagePropertyAccess(MessagePropertyType.HOST);
		return messagePropertyAccess.getMessagePropertyValue();
	}

	protected String getCMQueue() {
		IMessagePropertyAccess messagePropertyAccess = getMessagePropertyAccess(MessagePropertyType.CM_QUEUE);
		return messagePropertyAccess.getMessagePropertyValue();

	}
	
	protected String getCEPQueue() {
		IMessagePropertyAccess messagePropertyAccess = getMessagePropertyAccess(MessagePropertyType.CEP_QUEUE);
		return messagePropertyAccess.getMessagePropertyValue();

	}
	
	protected String getBPMSQueue() {
		IMessagePropertyAccess messagePropertyAccess = getMessagePropertyAccess(MessagePropertyType.BPMS_QUEUE);
		return messagePropertyAccess.getMessagePropertyValue();

	}
	
	protected String getExchange() {
		IMessagePropertyAccess messagePropertyAccess = getMessagePropertyAccess(MessagePropertyType.EXCHANGE);
		return messagePropertyAccess.getMessagePropertyValue();

	}
	
	protected String getRWExchange() {
		IMessagePropertyAccess messagePropertyAccess = getMessagePropertyAccess(MessagePropertyType.RW_EXCHANGE);
		return messagePropertyAccess.getMessagePropertyValue();

	}
	
	protected String getDWExchange() {
		IMessagePropertyAccess messagePropertyAccess = getMessagePropertyAccess(MessagePropertyType.DW_EXCHANGE);
		return messagePropertyAccess.getMessagePropertyValue();

	}
	
	protected String getVWExchange() {
		IMessagePropertyAccess messagePropertyAccess = getMessagePropertyAccess(MessagePropertyType.VW_EXCHANGE);
		return messagePropertyAccess.getMessagePropertyValue();

	}

	protected IMessagePropertyAccess getMessagePropertyAccess(
			MessagePropertyType type) {
		return getMessagePropertyFactory().getMessagePropertyAccess(type);
	}

	protected MessagePropertyAccessFactory getMessagePropertyFactory() {
		return MessagePropertyAccessFactory.getInstance();
	}
}
