package eu.osmose.cm.messages.types;

public class ContextManagerRequestIndividualMessage extends AMessage{

	private String ontology;
	private String uri;
	private String content;	
	
	public ContextManagerRequestIndividualMessage(String ontology, String uri) {
		this.ontology = ontology;
		this.uri = uri;
		this.content = "ontology="+ontology+AMessage.MESSAGE_SEPARATOR+"uri="+uri;
	}
	
	public ContextManagerRequestIndividualMessage(String content) {
		this.content = content; 
	}

	@Override
	public String getHeader() {
		return ContextManagerRequestIndividualMessage.class.getSimpleName();
	}

	@Override
	public String getContent() {
		return content;
	}
	
	public void setContent(String content) {
		this. content = content;
	}

	public String getOntology() {
		return ontology;
	}

	public void setOntology(String ontology) {
		this.ontology = ontology;
	}

	public String getUri() {
		return uri;
	}

	public void setUri(String uri) {
		this.uri = uri;
	}

}
