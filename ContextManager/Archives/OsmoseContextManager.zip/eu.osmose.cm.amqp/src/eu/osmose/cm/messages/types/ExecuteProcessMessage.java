package eu.osmose.cm.messages.types;

public class ExecuteProcessMessage {
	
	public ExecuteProcessMessage() {
		
	}

}
