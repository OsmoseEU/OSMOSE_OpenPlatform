package eu.osmose.cm.messages;

public abstract class AMessageProducer {

	private MessagePublisher messagePublisher;

	public AMessageProducer(MessagePublisher messagePublisher) {
		this.messagePublisher = messagePublisher;
	}

	public void publishMessage(String message) {
		this.messagePublisher.publishMessage(message);
	}
}
