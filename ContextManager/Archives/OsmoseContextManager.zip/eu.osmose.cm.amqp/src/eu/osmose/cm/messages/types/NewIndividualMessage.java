package eu.osmose.cm.messages.types;

public class NewIndividualMessage extends AMessage {

	private String ontology;
	private String uri;
	private String value;
	private String ontologyClass;

	public NewIndividualMessage(String ontology, String ontologyClass, String uri, String value) {
		this.setOntology(ontology);
		this.setUri(uri);
		this.setOntologyClass(ontologyClass);
		this.value = value;
	}

	@Override
	public String getHeader() {
		return this.getClass().getSimpleName();
	}

	@Override
	public String getContent() {
		return "ontology=" + ontology + AMessage.MESSAGE_SEPARATOR + "ontologyClass=" + ontologyClass
				+ AMessage.MESSAGE_SEPARATOR + "uri=" + uri + AMessage.MESSAGE_SEPARATOR + "value=" + value;
	}

	public String getOntology() {
		return ontology;
	}

	public void setOntology(String ontology) {
		this.ontology = ontology;
	}

	public String getUri() {
		return uri;
	}

	public void setUri(String uri) {
		this.uri = uri;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getOntologyClass() {
		return ontologyClass;
	}

	public void setOntologyClass(String ontologyClass) {
		this.ontologyClass = ontologyClass;
	}
}
