package eu.osmose.cm.messages.types;

public interface IMessage {
	public String getContent();
	public String getHeader();
	public String getMessage();
}
