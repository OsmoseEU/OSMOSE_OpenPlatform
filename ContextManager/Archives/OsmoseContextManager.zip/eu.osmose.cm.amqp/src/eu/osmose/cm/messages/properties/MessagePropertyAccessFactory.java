package eu.osmose.cm.messages.properties;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class MessagePropertyAccessFactory {
	protected static MessagePropertyAccessFactory instance;
	private final String PROPERTIES_FILENAME = "rabbitmq.properties";
	

	protected static Properties properties;

	protected MessagePropertyAccessFactory() {
		init();
	}

	public static synchronized MessagePropertyAccessFactory getInstance() {
		if (instance == null) {
			instance = new MessagePropertyAccessFactory();
		}
		return instance;
	}

	private void init() {
		initProperties();
	}

	private String getPropertiesPath() {
		return System.getProperty("jboss.home.dir").replace("\\", "/") + "/conf/ContextManager/" + PROPERTIES_FILENAME;
	}

	private void initProperties() {
		properties = new Properties();
		try {
			properties.load(new FileInputStream(new File(getPropertiesPath())));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			loadDefaultProperties();
		} catch (IOException e) {
			e.printStackTrace();
			loadDefaultProperties();
		}
	}

	private void loadDefaultProperties() {
		properties.put(MessagePropertyType.HOST.getPropertyKey(), "localhost");
		properties.put(MessagePropertyType.CM_QUEUE.getPropertyKey(), "ContextManagerQueue");	
		properties.put(MessagePropertyType.CEP_QUEUE.getPropertyKey(), "CEPQueue");
		properties.put(MessagePropertyType.BPMS_QUEUE, "BPMSQueue");
		properties.put(MessagePropertyType.MESSAGE_ENCODING.getPropertyKey(), "UTF-8");
		properties.put(MessagePropertyType.EXCHANGE.getPropertyKey(), "ContextManagerExchange");
	}
	
	public IMessagePropertyAccess getMessagePropertyAccess(MessagePropertyType messagePropertyType) {
		return new MessagePropertyAccess(properties.getProperty(messagePropertyType.getPropertyKey()));
	}

}
