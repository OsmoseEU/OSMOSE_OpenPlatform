package eu.osmose.cm.messages.types;



public class ClientMessage extends AMessage {
	
	private String header = "ClientHeader";
	private String content = "ClientContent";
	
	@Override
	public String getHeader() {
		return header;
	}

	@Override
	public String getContent() {
		return content;
	}

}
