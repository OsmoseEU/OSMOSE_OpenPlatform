package eu.osmose.cm.ontologies.access;

/**
 * Accessor class for ontologies.
 * 
 * @author Artur.Felic
 * 
 */
public class OntologyAccess implements IOntologyAccess {

	private String url;
	private String uri;

	public OntologyAccess(String url, String uri) {
		this.url = url;
		this.uri = uri;
	}

	@Override
	public String getOntologyUrl() {
		return this.url;
	}

	@Override
	public String getOntologyUri() {
		return this.uri;
	}

}
