package eu.osmose.cm.ontologies.access;

import eu.osmose.cm.ontologies.types.IOntologyType;

/**
 * Exception for ontology accessors
 * 
 * @author Artur.Felic
 * 
 */
public class OntologyAccessException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3149761068533289751L;

	public OntologyAccessException(IOntologyType ontologyType, String message) {
		super(ontologyType.name() + ": " + message);
	}
}
