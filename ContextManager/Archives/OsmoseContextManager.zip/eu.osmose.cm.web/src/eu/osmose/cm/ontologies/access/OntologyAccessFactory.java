package eu.osmose.cm.ontologies.access;

import eu.osmose.cm.ontologies.properties.IOntologyPropertyAccess;
import eu.osmose.cm.ontologies.properties.OnotlogyPropertyAccessFactory;
import eu.osmose.cm.ontologies.types.OntologyType;

/**
 * Factory for ontology accessors. Singleton.
 * 
 * @author Artur.Felic
 * 
 */
public final class OntologyAccessFactory extends OnotlogyPropertyAccessFactory {

	private static OntologyAccessFactory instance;

	private OntologyAccessFactory() {
		super();
	}

	public static synchronized OntologyAccessFactory getInstance() {
		if (instance == null) {
			instance = new OntologyAccessFactory();
		}
		return instance;
	}

	/**
	 * Getter for ontology accessors
	 * 
	 * @param ontologyType
	 * @return
	 */
	public IOntologyAccess getOntologyAccess(OntologyType ontologyType) {
		IOntologyPropertyAccess ontologyURL = getOntologyPropertyAccess(ontologyType.getUrl());
		IOntologyPropertyAccess ontologyURI = getOntologyPropertyAccess(ontologyType.getUri());
		return new OntologyAccess(ontologyURL.getOntologyPropertyValue(), ontologyURI.getOntologyPropertyValue());
	}

}
