package eu.osmose.cm.webservice;

import com.hp.hpl.jena.ontology.OntClass;
import com.hp.hpl.jena.ontology.OntModel;
import com.hp.hpl.jena.query.QueryExecution;
import com.hp.hpl.jena.query.QueryExecutionFactory;
import com.hp.hpl.jena.query.ResultSetFormatter;
import com.hp.hpl.jena.rdf.model.Property;
import com.hp.hpl.jena.rdf.model.Resource;
import com.hp.hpl.jena.rdf.model.Statement;

import eu.osmose.cm.ontologies.OntologyRepository;

/**
 * Web service for the context manager.
 * 
 * @author Artur.Felic
 * 
 */
public class ContextManagerWebService {
	
	public ContextManagerWebService() {
	}

	public String executeQuery(String queryString, String ontologyName) {

		OntModel ontology = getOntology(ontologyName);
		QueryExecution query = QueryExecutionFactory.create(queryString,
				ontology);
		return ResultSetFormatter.asText(query.execSelect());
	}

	public String getProperty(String ontologyName, String propertyUri) {
		OntModel ontology = getOntology(ontologyName);
		return ontology.getProperty(propertyUri).toString();
	}

	public String getResource(String ontologyName, String propertyUri) {
		OntModel ontology = getOntology(ontologyName);
		return ontology.getResource(propertyUri).toString();
	}

	public void addLiteral(String ontologyName, String resourceUri,
			String propertyUri, String literal) {
		OntModel ontology = getOntology(ontologyName);
		Property property = ontology.getProperty(propertyUri);
		Resource resource = ontology.getResource(resourceUri);
		resource.addLiteral(property, literal);
	}
	
	public String createIndividual(String ontologyName, String ontologyClassName, String individualName) {
		OntModel ontology = getOntology(ontologyName);
		String ns = ontology.getNsPrefixMap().get("");
		OntClass ontClass = ontology.getOntClass(ns + ontologyClassName);
		return ontology.createIndividual(ns + individualName, ontClass).toString();
	}

	public void createResource(String ontologyName, String resourceUri) {
		OntModel ontology = getOntology(ontologyName);
		ontology.createResource(resourceUri);
	}

	public String createProperty(String ontologyName, String propertyUri) {
		OntModel ontology = getOntology(ontologyName);
		return ontology.createProperty(propertyUri).toString();
	}

	public String createStatement(String ontologyName, String subjectUri,
			String predicateUri, String object) {
		OntModel ontology = getOntology(ontologyName);
		Statement statement = ontology.createStatement(
				ontology.getResource(subjectUri),
				ontology.getProperty(predicateUri), object);
		return statement.getString();
	}

	private OntModel getOntology(String ontologyName) {
		return OntologyRepository.getInstance().getOntology(ontologyName);
	}
	
	public String test() {
		return "test";
	}
	
}
