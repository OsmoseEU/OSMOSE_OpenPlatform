package eu.osmose.cm.ontologies;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import com.hp.hpl.jena.ontology.OntDocumentManager;
import com.hp.hpl.jena.ontology.OntModel;
import com.hp.hpl.jena.rdf.model.ModelFactory;

import eu.osmose.cm.ontologies.access.IOntologyAccess;
import eu.osmose.cm.ontologies.access.OntologyAccessFactory;
import eu.osmose.cm.ontologies.types.OntologyType;

/**
 * Repository holding initialized ontologies. Singleton.
 * 
 * @author Artur.Felic
 * 
 */
public class OntologyRepository {


	private static OntologyRepository instance;

	private Map<String, OntModel> ontologyMap;
	private Map<String, String> uriUrlMap;

	private OntologyRepository() {
		this.ontologyMap = new HashMap<String, OntModel>();
		initUriUrlMap();
	}

	private void initUriUrlMap() {
		uriUrlMap = new HashMap<String, String>();
		for(OntologyType ontologyType:OntologyType.values()) {
			IOntologyAccess ontologyAccess = OntologyAccessFactory.getInstance().getOntologyAccess(ontologyType);
			uriUrlMap.put(ontologyAccess.getOntologyUri(), ontologyAccess.getOntologyUrl());
		}
	}

	public static synchronized OntologyRepository getInstance() {
		if (instance == null)
			instance = new OntologyRepository();
		return instance;
	}

	/**
	 * Getter for initialized ontology access. Access will be created when not
	 * existent.
	 * 
	 * @param ontologyType
	 * @return
	 */
	public OntModel getOntology(String name) {
		OntModel ontology = ontologyMap.get(name);
		if (ontology == null) {
			ontology = initOntology(name);
			ontologyMap.put(name, ontology);
		}
		return ontology;
	}
	
	public String getOntologyUrl(String name) {
		IOntologyAccess ontologyAccess = getOntologyAccess(name);
		return ontologyAccess.getOntologyUrl();
	}
	
	private OntModel initOntology(String name) {
		IOntologyAccess ontologyAccess = getOntologyAccess(name);
		OntModel ontology = createOntology(ontologyAccess);
		return ontology;
	}

	private OntModel createOntology(IOntologyAccess ontologyAccess) {
		OntModel ontology = ModelFactory.createOntologyModel();
		OntDocumentManager documentManager = ontology.getDocumentManager();
		addOntologyReferencesToOntologyModel(documentManager);
		ontology.read(ontologyAccess.getOntologyUrl());
		return ontology;
	}

	private IOntologyAccess getOntologyAccess(String name) {
		OntologyType ontologyType = OntologyType.getOntologyTypeByName(name);
		return OntologyAccessFactory.getInstance()
				.getOntologyAccess(ontologyType);
	}

	private void addOntologyReferencesToOntologyModel(
			OntDocumentManager documentManager) {
		for(Entry<String, String> entry:uriUrlMap.entrySet()) {
			documentManager.addAltEntry(entry.getKey(), entry.getValue());
		}
		
	}
	
	public OntologyType[] getAvailableOntologies() {
		return OntologyType.values();
	}

}
