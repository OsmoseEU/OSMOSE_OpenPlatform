package eu.osmose.cm.messages;

import com.hp.hpl.jena.ontology.Individual;
import com.hp.hpl.jena.ontology.OntModel;
import com.hp.hpl.jena.rdf.model.Property;
import com.hp.hpl.jena.rdf.model.Statement;

import eu.osmose.cm.ontologies.OntologyRepository;

public class WarningMessageDelegator {
	
	private String messageContent;
	private MessageEndpoint messageEndpoint;

	public WarningMessageDelegator(String messageContent) {
		this.messageContent = messageContent;
	}
	
	public void delegateToContextManager() {
		messageEndpoint = new MessageEndpoint();
		String resourceUri = messageContent.substring(messageContent.indexOf("<eventResourceURI>")+18, messageContent.indexOf("</eventResourceURI>"));
		OntModel platformOntology = getOntology("PLATFORM");
		Individual i = platformOntology.getIndividual(resourceUri);
		Property p = platformOntology.getProperty("http://www.semanticweb.org/catarina/ontologies/2015/2/untitled-ontology-7#has_world");
		Statement s = i.getProperty(p);
		if(isDigitalWorldRelevant(s)) {
			messageEndpoint.getMessagePublisher().publishDWMessage("digitalization");
		} else if(isRealWorldRelevant(s)) {
			messageEndpoint.getMessagePublisher().publishDWMessage("internal");
		} else if (isVirtualWorldRelevant(s)) {
			messageEndpoint.getMessagePublisher().publishDWMessage("virtualization");
		} else {
			messageEndpoint.getMessagePublisher().publishDWMessage("do_nothing");
		}
	}

	private boolean isDigitalWorldRelevant(Statement s) {
		if(s.getObject().toString().endsWith("Digital_World"))
			return true;
		return false;
	}
	
	private boolean isVirtualWorldRelevant(Statement s) {
		if(s.getObject().toString().endsWith("Virtual_World"))
			return true;
		return false;
	}
	
	private boolean isRealWorldRelevant(Statement s) {
		if(s.getObject().toString().endsWith("Digital_World"))
			return true;
		return false;
	}

	private OntModel getOntology(String ontologyName) {
		return OntologyRepository.getInstance().getOntology(ontologyName);
	}
}
