package eu.osmose.cm.properties.type;

/**
 * Interface for property types.
 * 
 * @author Artur.Felic
 * 
 */
public interface IPropertyType {

	/**
	 * Getter for the key to the property.
	 * 
	 * @return
	 */
	public String getKey();
}
