package eu.osmose.cm.ontologies.access;


/**
 * Interface for ontology access classes.
 * 
 * @author Artur.Felic
 * 
 */
public interface IOntologyAccess{
	public String getOntologyUrl();
	public String getOntologyUri();
}
