package eu.osmose.cm.ontologies.properties;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

/**
 * Factory for property accessors. Singleton.
 * 
 * @author Artur.Felic
 * 
 */
public class OnotlogyPropertyAccessFactory {

	protected static OnotlogyPropertyAccessFactory instance;
	private final String PROPERTIES_FILENAME = "cm.properties";

	protected static Properties properties;

	protected OnotlogyPropertyAccessFactory() {
		init();
	}

	public static synchronized OnotlogyPropertyAccessFactory getInstance() {
		if (instance == null) {
			instance = new OnotlogyPropertyAccessFactory();
		}
		return instance;
	}

	private void init() {
		initProperties();
	}

	private String getPropertiesPath() {
		return System.getProperty("jboss.home.dir")+"\\conf\\ContextManager\\"+PROPERTIES_FILENAME;
	}

	private void initProperties() {
		properties = new Properties();
		try {
			properties.load(new FileInputStream(new File(getPropertiesPath())));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			loadDefaultProperties();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private void loadDefaultProperties() {
		properties.put("ontology_entity", "http://localhost:8090/eu.osmose.cm.web/ontologies/bfo.owl");
		properties.put("ontology_event", "http://localhost:8090/eu.osmose.cm.web/ontologies/lode.owl");
		properties.put("ontology_process", "http://localhost:8090/eu.osmose.cm.web/ontologies/ProcessKB.owl");
		properties.put("ontology_service", "http://localhost:8090/eu.osmose.cm.web/ontologies/OWLS.owl");
		properties.put("ontology_platform", "http://localhost:8090/eu.osmose.cm.web/ontologies/PlatformElements.owl");
		properties.put("ontology_bpmn", "http://localhost:8090/eu.osmose.cm.web/ontologies/BPMN20.owl");
		properties.put("ontology_entity_uri", "http://purl.obolibrary.org/obo/bfo.owl");
		properties.put("ontology_event_uri", "http://linkedevents.org/ontology/");
		properties.put("ontology_process_uri", "http://www.semanticweb.org/catarina/ontologies/2015/2/untitled-ontology-47");
		properties.put("ontology_service_uri", "http://www.daml.org/services/owl-s/1.1/Service.owl");
		properties.put("ontology_platform_uri", "http://www.semanticweb.org/catarina/ontologies/2015/2/untitled-ontology-7");
		properties.put("ontology_bpmn_uri", "http://dkm.fbk.eu/index.php/BPMN2_Ontology");
	}
	
	public IOntologyPropertyAccess getOntologyPropertyAccess(String key) {
		return new OntologyPropertyAccess(properties.getProperty(key));
	}
}
