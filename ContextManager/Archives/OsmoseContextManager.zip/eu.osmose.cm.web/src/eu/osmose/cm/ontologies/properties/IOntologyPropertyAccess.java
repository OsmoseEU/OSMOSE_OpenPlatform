package eu.osmose.cm.ontologies.properties;

/**
 * Accessor for single properties.
 * 
 * @author Artur.Felic
 * 
 */
public interface IOntologyPropertyAccess {

	/**
	 * Getter for the property value.
	 * 
	 * @return
	 */
	public String getOntologyPropertyValue();
}
