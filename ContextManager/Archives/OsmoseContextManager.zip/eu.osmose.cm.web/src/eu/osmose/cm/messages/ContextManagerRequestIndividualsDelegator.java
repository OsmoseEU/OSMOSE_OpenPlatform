package eu.osmose.cm.messages;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.hp.hpl.jena.ontology.Individual;
import com.hp.hpl.jena.ontology.OntClass;
import com.hp.hpl.jena.ontology.OntModel;
import com.hp.hpl.jena.rdf.model.Property;
import com.hp.hpl.jena.rdf.model.Statement;

import eu.osmose.cm.messages.types.ContextManagerResponseIndividualMessage;
import eu.osmose.cm.ontologies.OntologyRepository;

public class ContextManagerRequestIndividualsDelegator {
	
	private MessageEndpoint messageEndpoint;
	private String knowledgeLinkId;
	private String ontologyName;
	private String uri;

	public ContextManagerRequestIndividualsDelegator(String knowledgeLinkId, String ontologyName, String uri) {
		this.knowledgeLinkId = knowledgeLinkId;
		this.ontologyName=ontologyName;
		this.uri=uri;
		messageEndpoint = new MessageEndpoint();
	}
	
	public void delegateToContextManager() {
		OntModel ontology = getOntology(ontologyName);
		OntClass ontClass = ontology.getOntClass(uri);
		Iterator<?> iter = ontClass.listInstances();
		List<String> allIndividualsAndValues = new ArrayList<String>();
		while(iter.hasNext()) {
			Individual i = (Individual) iter.next();
			Property p = ontology.getProperty(i.getOntClass().toString()+"#"+"hasValue");
			Statement s = i.getProperty(p);
			allIndividualsAndValues.add(i.getURI()+"="+s.getDouble());
		}
		String content = allIndividualsAndValues.toString();
		ContextManagerResponseIndividualMessage response = new ContextManagerResponseIndividualMessage(knowledgeLinkId, ontologyName, uri, content);
		messageEndpoint.getMessagePublisher().publishMessage(response);
	}

	private OntModel getOntology(String ontologyName) {
		return OntologyRepository.getInstance().getOntology(ontologyName);
	}

}
