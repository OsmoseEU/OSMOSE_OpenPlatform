package eu.osmose.cm.messages;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

import eu.osmose.cm.messages.ContextManagerMessageConsumer;
import eu.osmose.cm.messages.MessageEndpoint;

@WebListener
public class ContextManagerActivator implements ServletContextListener {

	private MessageEndpoint messageEndpoint;

	@Override
	public void contextDestroyed(ServletContextEvent arg0) {
	}

	@Override
	public void contextInitialized(ServletContextEvent arg0) {
		messageEndpoint = new MessageEndpoint();
		messageEndpoint.getCMMessageSubscriber().addMessageConsumer(new ContextManagerMessageConsumer(messageEndpoint.getMessageChannel()));
	}

}
