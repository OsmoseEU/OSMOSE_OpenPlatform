package eu.osmose.cm.ontologies.properties;

/**
 * Accessor for single properties.
 * 
 * @author Artur.Felic
 * 
 */
public class OntologyPropertyAccess implements IOntologyPropertyAccess {

	protected String ontologyPropertyValue;

	public OntologyPropertyAccess(String ontologyPropertyValue) {
		this.ontologyPropertyValue = ontologyPropertyValue;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see eu.osmose.cm.properties.IPropertyAccess#getPropertyValue()
	 */
	@Override
	public String getOntologyPropertyValue() {
		return this.ontologyPropertyValue;
	}

}
