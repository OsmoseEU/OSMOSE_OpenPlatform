package eu.osmose.cm.messages;

import java.util.Iterator;
import java.util.logging.Logger;

import com.hp.hpl.jena.ontology.Individual;
import com.hp.hpl.jena.ontology.OntClass;
import com.hp.hpl.jena.ontology.OntModel;
import com.hp.hpl.jena.rdf.model.Literal;
import com.hp.hpl.jena.rdf.model.Property;

import eu.osmose.cm.ontologies.OntologyRepository;

public class NewIndividualMessageDelegator {
	private String ontologyName;
	private String ontologyClass;
	private String uri;
	private String value;
	
	Logger logger = Logger.getLogger(NewIndividualMessageDelegator.class.getSimpleName());
	
	public NewIndividualMessageDelegator(String ontologyName, String ontologyClass, String uri, String value) {
		this.ontologyName = ontologyName;
		this.ontologyClass = ontologyClass;
		this.uri = uri;
		this.value = value;
	}
	
	public void delegateToContextManager() {
		OntModel ontology = getOntology(ontologyName);
		OntClass ontClass = ontology.getOntClass(ontologyClass);
		Individual i = ontology.createIndividual(uri, ontClass);
		Literal valueLiteral = ontology.createTypedLiteral(Double.parseDouble(value));
		Property p = ontology.createProperty(ontClass.getURI()+"#"+"hasValue");
		i.addLiteral(p, valueLiteral);
		Iterator<?> iter = ontClass.listInstances();
		while(iter.hasNext()) {
			Individual ind = (Individual) iter.next();
			logger.info(ind.getURI()+" = "+ind.getProperty(p).getString());
		}
	}
	
	private OntModel getOntology(String ontologyName) {
		return OntologyRepository.getInstance().getOntology(ontologyName);
	}
}
