package eu.osmose.cm.messages;

import java.io.IOException;
import java.util.logging.Logger;

import com.rabbitmq.client.AMQP.BasicProperties;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Envelope;

import eu.osmose.cm.messages.AMessageConsumer;
import eu.osmose.cm.messages.types.AMessage;
import eu.osmose.cm.messages.types.ContextManagerRequestIndividualMessage;
import eu.osmose.cm.messages.types.NewIndividualMessage;
import eu.osmose.cm.messages.types.WarningMessage;

public class ContextManagerMessageConsumer extends AMessageConsumer {

	Logger logger = Logger.getLogger(ContextManagerMessageConsumer.class.getName());

	public ContextManagerMessageConsumer(Channel channel) {
		super(channel);
	}

	@Override
	public void handleDelivery(String consumerTag, Envelope envelope, BasicProperties properties, byte[] body)
			throws IOException {
		String message = new String(body, getMessageEncoding());
		String[] messageProperties = message.split(AMessage.MESSAGE_SEPARATOR);
		if (messageProperties[0].equals(NewIndividualMessage.class.getSimpleName())) {
			NewIndividualMessageDelegator delegator = new NewIndividualMessageDelegator(
					messageProperties[1].substring(messageProperties[1].indexOf("=") + 1),
					messageProperties[2].substring(messageProperties[2].indexOf("=") + 1),
					messageProperties[3].substring(messageProperties[3].indexOf("=") + 1),
					messageProperties[4].substring(messageProperties[4].indexOf("=") + 1));
			logger.info("[x] " + this.getClass().getSimpleName() + ": Received '"
					+ NewIndividualMessage.class.getSimpleName() + ": " + message + "'");
			delegator.delegateToContextManager();
		} else if (messageProperties[0].equals("WARNING")) {
			WarningMessageDelegator delegator = new WarningMessageDelegator(messageProperties[1]);
			logger.info("[x] " + this.getClass().getSimpleName() + ": Received '"
					+ WarningMessage.class.getSimpleName() + ": " + message + "'");
			delegator.delegateToContextManager();
		} else if (messageProperties[0].equals(ContextManagerRequestIndividualMessage.class.getSimpleName())) {
			ContextManagerRequestIndividualsDelegator delegator = new ContextManagerRequestIndividualsDelegator(messageProperties[1].substring(messageProperties[1].indexOf("=") + 1),
					messageProperties[2].substring(messageProperties[2].indexOf("=") + 1),
					messageProperties[3].substring(messageProperties[3].indexOf("=") + 1));
			logger.info("[x] " + this.getClass().getSimpleName() + ": Received '"
					+ ContextManagerRequestIndividualMessage.class.getSimpleName() + ": " + message + "'");
			delegator.delegateToContextManager();
		} else {
			logger.info("[x] " + this.getClass().getSimpleName() + ": Received '" + message + "'");
		}
	}

}
