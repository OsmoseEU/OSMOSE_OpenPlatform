package eu.osmose.cm.ontologies.types;


/**
 * Interface for ontology type classes.
 * 
 * @author Artur.Felic
 * 
 */
public interface IOntologyType {
	public String name();
}
