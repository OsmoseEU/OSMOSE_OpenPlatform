package eu.osmose.cm.ontologies.types;

/**
 * Enumeration for the different ontology types.
 * 
 * @author Artur.Felic
 * 
 */
public enum OntologyType implements IOntologyType {
	ENTITY("ontology_entity", "ontology_entity_uri"), EVENT("ontology_event",
			"ontology_event_uri"), PROCESS("ontology_process",
			"ontology_process_uri"), BPMN("ontology_bpmn", "ontology_bpmn_uri"), SERVICE(
			"ontology_service", "ontology_service_uri"), PLATFORM(
			"ontology_platform", "ontology_platform_uri"), KNOWELDGE_LINK_ONTOLOGY(
			"knowledge_link_ontology", "knowledge_link_ontology_uri"), AGGREGATED_ONTOLOGY(
			"aggregated_ontology", "aggregated_ontology_uri"), MEASUREMENT_ONTOLOGY(
			"measurement_ontology", "measurement_ontology_uri"), DEVIATION_ONTOLOGY(
			"deviation_ontology", "deviation_ontology_uri");

	private String urlKey;
	private String uriKey;

	private OntologyType(String url, String uri) {
		this.urlKey = url;
		this.uriKey = uri;
	}

	public String getUrl() {
		return urlKey;
	}

	public String getUri() {
		return uriKey;
	}

	public static OntologyType getOntologyTypeByName(String name) {
		for (OntologyType ontologyType : OntologyType.values()) {
			if (ontologyType.name().equals(name)) {
				return ontologyType;
			}
		}
		return null;
	}
}
