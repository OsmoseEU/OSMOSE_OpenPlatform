package eu.osmose.cm.webservice;

import java.util.ArrayList;
import java.util.List;

import eu.osmose.cm.ontologies.OntologyRepository;
import eu.osmose.cm.ontologies.access.IOntologyAccess;
import eu.osmose.cm.ontologies.access.OntologyAccessFactory;
import eu.osmose.cm.ontologies.types.OntologyType;

public class ContextManagerTestService {

	
	public static final String ONTOLOGY_SEPARATOR = "##";
	
	public ContextManagerTestService() {
		
	}
	
	public String getResourceTest() {
		ContextManagerWebService cmws = new ContextManagerWebService();
		return cmws.getResource("MEASUREMENT_ONTOLOGY", "http://www.semanticweb.org/artur.felic/ontologies/2015/6/CamshaftMeasurement#CamshaftMeasurement");
	}
	
	public String getOntologyUrl(String ontology) {
		return OntologyRepository.getInstance().getOntologyUrl(ontology);
	}
	
	public String[] getAvailableOntologies() {
		List<String> result = new ArrayList<String>();
		for(OntologyType type:OntologyRepository.getInstance().getAvailableOntologies()) {
			IOntologyAccess ontologyAccess = OntologyAccessFactory.getInstance().getOntologyAccess(type);
			result.add(type.name()+ONTOLOGY_SEPARATOR+ontologyAccess.getOntologyUri()+ONTOLOGY_SEPARATOR+ontologyAccess.getOntologyUrl());
		}
		
		return result.toArray(new String[]{});
	}
	
}
