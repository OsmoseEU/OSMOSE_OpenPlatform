/**
 * ContextManagerWebService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package eu.osmose.cm.webservice;

public interface ContextManagerWebService extends java.rmi.Remote {
    public java.lang.String getProperty(java.lang.String ontologyName, java.lang.String propertyUri) throws java.rmi.RemoteException;
    public java.lang.String getResource(java.lang.String ontologyName, java.lang.String propertyUri) throws java.rmi.RemoteException;
    public void test() throws java.rmi.RemoteException;
    public void createResource(java.lang.String ontologyName, java.lang.String resourceUri) throws java.rmi.RemoteException;
    public java.lang.String createIndividual(java.lang.String ontologyName, java.lang.String ontologyClassName, java.lang.String individualName) throws java.rmi.RemoteException;
    public java.lang.String createProperty(java.lang.String ontologyName, java.lang.String propertyUri) throws java.rmi.RemoteException;
    public java.lang.String executeQuery(java.lang.String queryString, java.lang.String ontologyName) throws java.rmi.RemoteException;
    public void addLiteral(java.lang.String ontologyName, java.lang.String resourceUri, java.lang.String propertyUri, java.lang.String literal) throws java.rmi.RemoteException;
    public void testMessage() throws java.rmi.RemoteException;
    public java.lang.String createStatement(java.lang.String ontologyName, java.lang.String subjectUri, java.lang.String predicateUri, java.lang.String object) throws java.rmi.RemoteException;
}
