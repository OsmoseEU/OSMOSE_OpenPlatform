package eu.osmose.cm.webservice;

public class ContextManagerTestServiceProxy implements eu.osmose.cm.webservice.ContextManagerTestService {
  private String _endpoint = null;
  private eu.osmose.cm.webservice.ContextManagerTestService contextManagerTestService = null;
  
  public ContextManagerTestServiceProxy() {
    _initContextManagerTestServiceProxy();
  }
  
  public ContextManagerTestServiceProxy(String endpoint) {
    _endpoint = endpoint;
    _initContextManagerTestServiceProxy();
  }
  
  private void _initContextManagerTestServiceProxy() {
    try {
      contextManagerTestService = (new eu.osmose.cm.webservice.ContextManagerTestServiceServiceLocator()).getContextManagerTestService();
      if (contextManagerTestService != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)contextManagerTestService)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)contextManagerTestService)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (contextManagerTestService != null)
      ((javax.xml.rpc.Stub)contextManagerTestService)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public eu.osmose.cm.webservice.ContextManagerTestService getContextManagerTestService() {
    if (contextManagerTestService == null)
      _initContextManagerTestServiceProxy();
    return contextManagerTestService;
  }
  
  public java.lang.String getResourceTest() throws java.rmi.RemoteException{
    if (contextManagerTestService == null)
      _initContextManagerTestServiceProxy();
    return contextManagerTestService.getResourceTest();
  }
  
  
}