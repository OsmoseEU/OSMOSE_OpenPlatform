/**
 * ContextManagerWebServiceServiceLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package eu.osmose.cm.webservice;

public class ContextManagerWebServiceServiceLocator extends org.apache.axis.client.Service implements eu.osmose.cm.webservice.ContextManagerWebServiceService {

    public ContextManagerWebServiceServiceLocator() {
    }


    public ContextManagerWebServiceServiceLocator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public ContextManagerWebServiceServiceLocator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for ContextManagerWebService
    private java.lang.String ContextManagerWebService_address = "http://localhost:8090/eu.osmose.cm.web/services/ContextManagerWebService";

    public java.lang.String getContextManagerWebServiceAddress() {
        return ContextManagerWebService_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String ContextManagerWebServiceWSDDServiceName = "ContextManagerWebService";

    public java.lang.String getContextManagerWebServiceWSDDServiceName() {
        return ContextManagerWebServiceWSDDServiceName;
    }

    public void setContextManagerWebServiceWSDDServiceName(java.lang.String name) {
        ContextManagerWebServiceWSDDServiceName = name;
    }

    public eu.osmose.cm.webservice.ContextManagerWebService getContextManagerWebService() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(ContextManagerWebService_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getContextManagerWebService(endpoint);
    }

    public eu.osmose.cm.webservice.ContextManagerWebService getContextManagerWebService(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            eu.osmose.cm.webservice.ContextManagerWebServiceSoapBindingStub _stub = new eu.osmose.cm.webservice.ContextManagerWebServiceSoapBindingStub(portAddress, this);
            _stub.setPortName(getContextManagerWebServiceWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setContextManagerWebServiceEndpointAddress(java.lang.String address) {
        ContextManagerWebService_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (eu.osmose.cm.webservice.ContextManagerWebService.class.isAssignableFrom(serviceEndpointInterface)) {
                eu.osmose.cm.webservice.ContextManagerWebServiceSoapBindingStub _stub = new eu.osmose.cm.webservice.ContextManagerWebServiceSoapBindingStub(new java.net.URL(ContextManagerWebService_address), this);
                _stub.setPortName(getContextManagerWebServiceWSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("ContextManagerWebService".equals(inputPortName)) {
            return getContextManagerWebService();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("http://webservice.cm.osmose.eu", "ContextManagerWebServiceService");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("http://webservice.cm.osmose.eu", "ContextManagerWebService"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        
if ("ContextManagerWebService".equals(portName)) {
            setContextManagerWebServiceEndpointAddress(address);
        }
        else 
{ // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
