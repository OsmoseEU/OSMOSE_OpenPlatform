/**
 * ContextManagerTestServiceService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package eu.osmose.cm.webservice;

public interface ContextManagerTestServiceService extends javax.xml.rpc.Service {
    public java.lang.String getContextManagerTestServiceAddress();

    public eu.osmose.cm.webservice.ContextManagerTestService getContextManagerTestService() throws javax.xml.rpc.ServiceException;

    public eu.osmose.cm.webservice.ContextManagerTestService getContextManagerTestService(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
