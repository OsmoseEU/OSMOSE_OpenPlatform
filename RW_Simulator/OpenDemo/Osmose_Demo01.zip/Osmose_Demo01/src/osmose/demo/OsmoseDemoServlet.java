package osmose.demo;

import java.io.IOException;
import java.io.Writer;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//import com.javacodegeeks.enterprise.rest.resteasy.SendStartSimulation;
import com.rabbitmq.client.AMQP;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.Consumer;
import com.rabbitmq.client.DefaultConsumer;
import com.rabbitmq.client.Envelope;

/**
 * Servlet implementation class OsmoseDemoServlet
 */
@WebServlet("/OsmoseDemoServlet")
public class OsmoseDemoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public static String messageinQueue;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public OsmoseDemoServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	System.out.println("WE r in the servlet + message in queue" +messageinQueue );
    	ConnectionFactory factory = new ConnectionFactory();
        factory.setHost("localhost");
        Connection connection = factory.newConnection();
        Channel channel = connection.createChannel();
        channel.exchangeDeclare("REALWORLD","fanout", true);
        
        channel.queueDeclare("RWQueue", false, false, false, null);
        channel.queueBind("RWQueue", "REALWORLD", "");
        System.out.println(" [*] Waiting for messages in doGet(). To exit press CTRL+C");
     
        Consumer consumer = new DefaultConsumer(channel){    	 
          @Override
          public void handleDelivery(String consumerTag, Envelope envelope, AMQP.BasicProperties properties, byte[] body)
              throws IOException {
            String message = new String(body, "UTF-8");
            System.out.println("message in the servlet" + message);
            //High temperature event, control for overheating
            if(message.contains("EventType = '3'")&&!message.contains("SubEventId = '18'"))
            {
            		//OverheatingConfirmedMsg();
            		pass(message);
            		
            System.out.println("In the queue in servlet ......");
            }
            else if(message.contains("EventType = '26'")&&!message.contains("SubEventId = '2'")) {
            	//Earthquake confirmation
            	pass(message);
            System.out.println(" [x] Received in servlet'" + message + "'");}
          
          else if(message.contains("EventType = '21'")&&!message.contains("SubEventId = '4'")) {
        	  //panic button confirmation
            	pass(message);
            System.out.println(" [x] Received in servlet'" + message + "'");}
        
          else
        	  pass(message);}
        };
       
    
    channel.basicConsume("RWQueue", true, consumer);
   
    channel.close();
    String responseToBuild = messageinQueue;
    System.out.println("Response from the queue = " + responseToBuild);
        
		//String output = r.toString();
		Writer w = response.getWriter();
		if (responseToBuild!=null)
		w.write(responseToBuild);
        }
       
        
	//}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	public static void OverheatingConfirmedMsg() throws IOException
	{
		
		ConnectionFactory factory = new ConnectionFactory();
	    Connection connection = factory.newConnection();
	    factory.setHost("localhost");
	    Channel channel = connection.createChannel();
		channel.exchangeDeclare("REALWORLD","fanout", true);
		  
       	String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
    	String message = "<Event EventId= '1' Domain = 'OsmoseDemo' EventType = '3' Timestamp = '" + timeStamp + "' EventStatus = 'A' ItemId = '1' SubEventId = '18'></Event>";
        	
    	channel.basicPublish("REALWORLD","" , null, message.getBytes());
        System.out.println(" [x] Sent from overheating '" + message);
        channel.close();
		
	}

	 public static String pass(String message){
			System.out.println("message from the queue servlet = " + message);
			messageinQueue = message;
				return message;
			}
}
