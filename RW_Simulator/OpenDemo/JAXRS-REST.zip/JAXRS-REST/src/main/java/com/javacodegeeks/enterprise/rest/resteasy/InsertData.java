package com.javacodegeeks.enterprise.rest.resteasy;

import java.io.InputStream;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

public class InsertData {
	
	 public void insertDataBase(String timeStamp,String temperature, String pressure, String axelSimX, String axelSimY, 
			 String humidity, String gas, String panic ) throws Exception {
		    try {
		      // This will load the MySQL driver, each DB has its own driver
		      Class.forName("com.mysql.jdbc.Driver");
		     System.out.println("11111111111111");
		      // Setup the connection with the DB
		      	      
		      String myDriver = "org.gjt.mm.mysql.Driver";
		        String myUrl = "jdbc:mysql://localhost:3306/osmose_service_svil";
		      
		      Class.forName(myDriver);
		       java.sql.Connection conn =  DriverManager.getConnection(myUrl, "root", "root");
		       String query = " insert into od_attributevalue (itemid,attributeid,value)"
		  	    	        + " values('1', '1'," + temperature + "),"
		  	    	        + "('1','4'," + panic + "),"
		  	    	        + "('1','2'," + pressure +"),"
		  	    	        + "('1','3'," + gas + "),"
		  	    	        + "('1','5'," + axelSimX + "),"
		  	    	        + "('1','6'," + axelSimY + "),"
		  	    	        + "('1','7'," + humidity + ")"
		  	    	            ;
  System.out.println("Query = " + query);
  PreparedStatement preparedStmt = ((java.sql.Connection) conn).prepareStatement(query);
 	  
		  		preparedStmt.execute();
		      conn.close();
 
		    }
		      catch (Exception e)
		      {
		        System.err.println("Got an exception!");
		        System.err.println(e.getMessage());
		     
	 
		    }}
	 public void insertEvents(String timeStamp,String eventTypeId, String eventStatus, String domain ) throws Exception {
		    try {
		    	  Class.forName("com.mysql.jdbc.Driver");
				     System.out.println("Insert Events...........");
				      // Setup the connection with the DB
				      	      
				      String myDriver = "org.gjt.mm.mysql.Driver";
				        String myUrl = "jdbc:mysql://localhost:3306/osmose_service_svil";
				      
				      Class.forName(myDriver);
				       java.sql.Connection conn =  DriverManager.getConnection(myUrl, "root", "root");
				       String query = " insert into od_event (eventtypeid,eventstatus,itemid,domain)"
				  	    	        + " values('" + eventTypeId +  "','" + eventStatus + "','1','test')"
  	    	      
				  	    	            ;
		  System.out.println("Query = " + query);
		  PreparedStatement preparedStmt = ((java.sql.Connection) conn).prepareStatement(query);
		 	  
				  		preparedStmt.execute();
				      conn.close();
		    }
		  
		    catch (Exception e)
		      {
		        System.err.println("Got an exception!");
		        System.err.println(e.getMessage());
		     
	 
		    }
		    }
	 public void pushGFTEvents(String eventTypeId, String eventStatus)
	 {
		 System.setProperty("java.net.useSystemProxies", "true");
			System.setProperty("http.proxyHost", "proxy.reply.it");
			System.setProperty("http.proxyPort", "8080");
			Client client = Client.create();
		 
			WebResource webResource = client
					.resource("http://osmose.gftitalia.it/osmosesrv/OsmoseServices/addEvent");
			String inputEvent = "typeId="+	eventTypeId + "&status="+eventStatus+"&itemId=1&domain=test";
			//String input = "typeId=2&status=A&itemId=1&domain=test";
System.out.println("Insert Event in GFT DB = " + inputEvent);
			ClientResponse response = webResource.type("application/json")
					.post(ClientResponse.class, inputEvent);
			System.out.println("Events....");
			if (response.getStatus() != 200) {
				throw new RuntimeException("Failed : HTTP error code : "
						+ response.getStatus());
			}

			System.out.println("Output from Server .... \n");
			String output = response.getEntity(String.class);
			System.out.println(output);

	 }
	 //insData.pushGFTAttribute(urlparm, pressure, axelSimX, axelSimY, humidity, gas, panic);
	 
	 public void pushGFTAttribute(String temp, String pressure, String axelSimX, String axelSimY, String humidity, String gas, String panic)
	 {
		 System.setProperty("java.net.useSystemProxies", "true");
			System.setProperty("http.proxyHost", "proxy.reply.it");
			System.setProperty("http.proxyPort", "8080");
		 Client client = Client.create();
		 String url = "http://osmose.gftitalia.it/osmosesrv/OsmoseServices/addAttributeValueFix?temp=" + temp + 
				  "&pressure=" + pressure + "&axelSimX=" +  axelSimX + "&axelSimY=" + axelSimY + "&humidity=" +
				  humidity + "&gas="+gas+"&panic=" + panic;
			WebResource webResource = client
					//.resource("http://osmose.gftitalia.it/osmosesrv/OsmoseServices/addAttributeValueArray");
					.resource(url);
			//String inputAttribute = "1="+temp+"&2="+pressure+"&3=" + gas + "&4=" + panic + "&5=" + axelSimX + "&6=" +axelSimY + "&7=" + humidity;
			//String inputAttribute = "attributes=1%3D" + temp+"&2="+pressure+"&3=" + gas + "&4=" + panic + "&5=" + axelSimX + "&6=" +axelSimY + "&7=" + humidity + "\"";
			ClientResponse response = webResource.accept("application/json").get(ClientResponse.class);
			
					
					
					//.post(ClientResponse.class, inputAttribute);
			//System.out.println("Attributes...." + inputAttribute);
			if (response.getStatus() != 200) {
				throw new RuntimeException("Failed : HTTP error code : "
						+ response.getStatus());
			}

			System.out.println("Output from Server .... \n");
			String output = response.getEntity(String.class);
			System.out.println(output);

	 }
	 

}
