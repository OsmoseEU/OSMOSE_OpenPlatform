package com.javacodegeeks.enterprise.rest.resteasy;

import java.util.HashSet;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;

import javax.ws.rs.core.Application;
 

public class MyRESTApplication  extends Application {
	
	private Set<Object> singletons = new HashSet<Object>();
	 
	public MyRESTApplication() {
		singletons.add(new RESTEasyService());
		//This function will trigger automatically every 5 sec the SayHello method
		/*Timer timer = new Timer();
		timer.schedule(new SayHello(), 0, 5000);*/

	}
 
	@Override
	public Set<Object> getSingletons() {
		return singletons;
	}

	@Override
	public Set<Class<?>> getClasses() {
		// TODO Auto-generated method stub
		return null;
	}
	
	/*class SayHello extends TimerTask {
	    public void run() {
	    	
	       System.out.println("Hello World!"); 
	    }
	}*/

}
