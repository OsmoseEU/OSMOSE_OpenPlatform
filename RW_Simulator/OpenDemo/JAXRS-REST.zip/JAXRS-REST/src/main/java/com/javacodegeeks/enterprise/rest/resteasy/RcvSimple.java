package com.javacodegeeks.enterprise.rest.resteasy;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.TimeoutException;

import javax.ws.rs.client.Client;

import com.rabbitmq.client.AMQP;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.Consumer;
import com.rabbitmq.client.DefaultConsumer;
import com.rabbitmq.client.Envelope;



	public class RcvSimple {
		private final static String QUEUE_NAME = "XMLMessageQueue";
		
		public static void main(String[] argv)
	                  throws Exception {
	    	
			
			ConnectionFactory factory = new ConnectionFactory();
		    factory.setHost("localhost");
		    final Connection connection = factory.newConnection();
		    final Channel channel = connection.createChannel();
		    channel.queueDeclare(QUEUE_NAME, false, false, false, null);
		    
		    System.out.println(" [*] Waiting for messages. To exit press CTRL+C");
		    //final String resultToSend = Culculation();
		    
		     final Consumer consumer = new DefaultConsumer(channel) {
		      @Override
		      public void handleDelivery(String consumerTag, Envelope envelope, AMQP.BasicProperties properties, byte[] body)
		          throws IOException {
		        String message = new String(body, "UTF-8");
		        //String url = ;
		        URL url = new URL("http://localhost:8090/JAXRS-RESTEasy/rest/rest/recieve");
		        HttpURLConnection connection =
		            (HttpURLConnection) url.openConnection();
		        connection.setRequestMethod("GET");
		        connection.setRequestProperty("Accept", "text/html");
		        connection.disconnect();
			    /*String queueName = "ContextManagerQueue1";
			    channel.queueDeclare(queueName, false, false, false, null);
		       	channel.queueBind(queueName, "ContextManagerExchange", "");
		       	System.out.println(resultToSend);
		       	channel.basicPublish("ContextManagerExchange", queueName, null, resultToSend.getBytes());
		       	//channel.close();
			    //connection.close();
		      	 */   	
		        System.out.println(" [x] Received '" + message + "'" + "calculation result = ");
		        }
		     
		    };
		    channel.basicConsume(QUEUE_NAME, true, consumer);
			
		 	        
	    }
		/*public static String Culculation() throws IOException, TimeoutException
		{
			//here we could place some calculation on parameters for the smart tool
			String result = "para";
			int upper = 100;
			int lower = 10;
			int r = (int) (Math.random() * (upper - lower)) + lower;
	        result = "ResultOfTheCalc= " + Integer.toString(r) + " ;";
			ConnectionFactory factory = new ConnectionFactory();
			com.rabbitmq.client.Connection connection = factory.newConnection();
		    Channel channel = connection.createChannel();
		   	factory.setHost("localhost");	
		   	factory.setUsername("guest");
		   	factory.setPassword("guest");
		   	channel.exchangeDeclare("ContextManagerExchange", "fanout", true);
		   	String queueName = "TEST";
		   	System.out.println("queueName= " + queueName);
		  	channel.queueDeclare(queueName, false, false, false, null);
		   	//channel.queueBind(queueName, "ContextManagerExchange", "");
		    channel.basicPublish("", queueName, null, result.getBytes());
		    //channel.basicPublish("", "ContextManagerExchange", null, result.getBytes());
		   	channel.close();
					
					System.out.println("Java Queue - Message RabbitMQ Java Sent: '" + result + "'");
					
					channel.close();
					//connection.close();
			
	        			
			return result;
		}*/

	}


