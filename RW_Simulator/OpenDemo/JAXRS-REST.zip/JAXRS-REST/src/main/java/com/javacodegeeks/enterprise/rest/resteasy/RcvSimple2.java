package com.javacodegeeks.enterprise.rest.resteasy;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.TimeoutException;

import javax.ws.rs.client.Client;

import com.rabbitmq.client.AMQP;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.Consumer;
import com.rabbitmq.client.DefaultConsumer;
import com.rabbitmq.client.Envelope;



	public class RcvSimple2 {
private final static String QUEUE_NAME = "XMLMessageQueue";
		
		public static void main(String[] argv)
	                  throws Exception {
	    	
			
			ConnectionFactory factory = new ConnectionFactory();
	        factory.setHost("localhost");
	        final Connection consumerConnection = factory.newConnection();
	        final Connection publisherConnection = factory.newConnection();

	        final Channel consumerChannel = consumerConnection.createChannel();
	        consumerChannel.queueDeclare("REALWORLD", false, false, false, null);

	        final Channel publisherChannel = publisherConnection.createChannel();
	        final String queueName = "TEST";
	        //publisherChannel.queueDeclare(queueName, false, false, false, null);
	        publisherChannel.queueBind("REALWORLD", "ContextManagerExchange", "");

	        System.out.println(" [*] Waiting for messages. To exit press CTRL+C");
	     

	        final Consumer consumer = new DefaultConsumer(consumerChannel) {
	            @Override
	            public void handleDelivery(String consumerTag, Envelope envelope, AMQP.BasicProperties properties, byte[] body)
	                    throws IOException {
	                String message = new String(body, "UTF-8");
	                String resultToSend = null;
					
						resultToSend = "New message";//Culculation();
					
	                System.out.println(resultToSend);
	                
	                publisherChannel.basicPublish("REALWORLD", "", null, resultToSend.getBytes());
	                //System.out.println(" [x] Received '" + message + "'" + "calculation result = ");
	            }

	        };
	        consumerChannel.basicConsume(QUEUE_NAME, true, consumer);
	    }
		public static String Culculation() throws IOException, TimeoutException
		{
			//here we could place some calculation on parameters for the smart tool
			String result = "para";
			int upper = 100;
			int lower = 10;
			int r = (int) (Math.random() * (upper - lower)) + lower;
	        result = "ResultOfTheCalc= " + Integer.toString(r) + " ;";
								
					System.out.println("Java Queue - Message RabbitMQ Java Sent: '" + result + "'");
		    			
			return result;
		}

	}

