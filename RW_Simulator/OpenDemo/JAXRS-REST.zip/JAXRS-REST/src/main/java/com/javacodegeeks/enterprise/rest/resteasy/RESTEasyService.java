package com.javacodegeeks.enterprise.rest.resteasy;



import java.io.IOException;
import java.net.URISyntaxException;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;

import java.util.Timer;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
/*********************/
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;

import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;


import com.javacodegeeks.enterprise.rest.resteasy.SendStartSimulation.SayHello;
import com.rabbitmq.client.AMQP;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.Consumer;
import com.rabbitmq.client.DefaultConsumer;
import com.rabbitmq.client.Envelope;

@Path("/rest")
public class RESTEasyService {
	final ExecutorService exService = Executors.newSingleThreadExecutor();
	 private Connection connect = null;
	  private Statement statement = null;
	  private PreparedStatement preparedStatement = null;
	  private ResultSet resultSet = null;
	  private String AxelerometerValueOld = null;
	  private String tempSimOld = null;
	  private String humSimOld = null;
	  private String presSimOld = null;
	  private String panicOld = null;
	  public static String messageinQueue;
	  

		// And From your main() method or any other method
		
	
	//Test GET service just to see it up and running 
	@GET
	@Path("/test")
	@Consumes(MediaType.TEXT_HTML)
	@Produces(MediaType.TEXT_HTML)
	public Response testService(){
	System.out.println("We r in the test bla-bla service. New param test!!!!!!!!!");
	return Response.status(200).build();
	}
	Timer timer = new Timer();
	Boolean timerStarted = false;
	@GET
	@Path("/start")
	@Consumes(MediaType.TEXT_HTML)
	@Produces(MediaType.TEXT_HTML)
	public Response testStartSimulation(){
	System.out.println("We r in the test start simulation");
		if ( ! timerStarted ){
	   timer.schedule(new SayHello(), 0, 10000);
	}else{
	   System.out.println("Warning timer already started!!!!!!!");
	}
	timer.schedule(new SayHello(), 0, 10000);
	timerStarted = true;
	return Response.status(200).build();
	}
	@GET
	@Path("/stop")
	@Consumes(MediaType.TEXT_HTML)
	@Produces(MediaType.TEXT_HTML)
	public Response testStopSimulation() throws IOException{
	System.out.println("We r in the test stort simulation");
	//Timer timer = new Timer();
    timer.cancel();
    //timer.purge();
    ConnectionFactory factory = new ConnectionFactory();
	com.rabbitmq.client.Connection connection = factory.newConnection();
    Channel channel = connection.createChannel();
   	factory.setHost("localhost");	
   	factory.setUsername("guest");
   	factory.setPassword("guest");
   	//channel.queueBind("MonitoringQueue", "ContextManagerExchange", "");
   	channel.queueDelete("MonitoringQueue", false, false);
	return Response.status(200).build();
	}
	
	@GET
	@Path("/listenForExchange")
	@Consumes(MediaType.TEXT_HTML)
	@Produces(MediaType.TEXT_HTML)
	public Response ListenForExchange() throws IOException{
	System.out.println("We r in listener");
	//final Response response;
	//Listen for the REALWORLD exchange 
	ConnectionFactory factory = new ConnectionFactory();
    factory.setHost("localhost");
    Connection connection = factory.newConnection();
    Channel channel = connection.createChannel();
    channel.exchangeDeclare("REALWORLD","fanout", true);
    
    channel.queueDeclare("RWQueue", false, false, false, null);
    channel.queueBind("RWQueue", "REALWORLD", "");
    System.out.println(" [*] Waiting for messages. To exit press CTRL+C");
    //response = Response.status(200).build();
    Consumer consumer = new DefaultConsumer(channel) {
      @Override
      public void handleDelivery(String consumerTag, Envelope envelope, AMQP.BasicProperties properties, byte[] body)
          throws IOException {
        String message = new String(body, "UTF-8");
        if(message.contains("EventType = '3'")&&!message.contains("SubEventId = '18'"))
        {
        		SendStartSimulation.OverheatingConfirmedMsg();
        		pass(message);
        		
        System.out.println("In the queue......");
        }
        else{
        	pass(message);
        System.out.println(" [x] Received '" + message + "'");}
      }
    };
channel.basicConsume("RWQueue", true, consumer);
String responseToBuild = messageinQueue;
//channel.close();
System.out.println("Response from the queue = " + responseToBuild);
    
	
	return Response.status(200).entity(responseToBuild).build();
	}
	
	//Service to publish confirmation of the alarms
	@GET
	@Path("/T_alarmConfirmed")
	@Consumes(MediaType.TEXT_HTML)
	@Produces(MediaType.TEXT_HTML)
	public Response alarmConfirmedT() throws IOException{
	System.out.println("We r in the service confirming the alerts Temperature");
	ConnectionFactory factory = new ConnectionFactory();
	com.rabbitmq.client.Connection connection = factory.newConnection();
    Channel channel = connection.createChannel();
   	factory.setHost("localhost");	
   	factory.setUsername("guest");
   	factory.setPassword("guest");
   	channel.exchangeDeclare("REALWORLD", "fanout", true);
   	String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
	String message = "<Event EventId= '1' Domain = 'OsmoseDemo' EventType = '3' Timestamp = '" + timeStamp + "' EventStatus = 'A' ItemId = '1' SubEventId = '18'></Event>";
    channel.basicPublish("REALWORLD", "", null, message.getBytes());
   	channel.close();
	return Response.status(200).build();
	}

	//Service to publish confirmation of the alarms
	@GET
	@Path("/E_alarmConfirmed")
	@Consumes(MediaType.TEXT_HTML)
	@Produces(MediaType.TEXT_HTML)
	public Response alarmConfirmedE() throws IOException{
	System.out.println("We r in the service confirming the alerts Earthquake");
	ConnectionFactory factory = new ConnectionFactory();
	com.rabbitmq.client.Connection connection = factory.newConnection();
    Channel channel = connection.createChannel();
   	factory.setHost("localhost");	
   	factory.setUsername("guest");
   	factory.setPassword("guest");
   	channel.exchangeDeclare("REALWORLD", "fanout", true);
   	String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
	String message = "<Event EventId= '1' Domain = 'OsmoseDemo' EventType = '26' Timestamp = '" + timeStamp + "' EventStatus = 'A' ItemId = '1' SubEventId = '2'></Event>";
     channel.basicPublish("REALWORLD", "", null, message.getBytes());
   	channel.close();
	return Response.status(200).build();
	}
	//Service to publish rejection of the alarms
		@GET
		@Path("/T_alarmRegected")
		@Consumes(MediaType.TEXT_HTML)
		@Produces(MediaType.TEXT_HTML)
		public Response alarmRejectedT() throws IOException{
		System.out.println("We r in the service rejecting the alerts High Temperature");
		ConnectionFactory factory = new ConnectionFactory();
		com.rabbitmq.client.Connection connection = factory.newConnection();
	    Channel channel = connection.createChannel();
	   	factory.setHost("localhost");	
	   	factory.setUsername("guest");
	   	factory.setPassword("guest");
	   	channel.exchangeDeclare("REALWORLD", "fanout", true);
	   	String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
		String message = "<Event EventId= '1' Domain = 'OsmoseDemo' EventType = '24' Timestamp = '" + timeStamp + "' EventStatus = 'A' ItemId = '1' SubEventId = '18'></Event>";
	     channel.basicPublish("REALWORLD", "", null, message.getBytes());
	   	channel.close();
		return Response.status(200).build();
		}
	
		//Service to publish rejection of the alarms
				@GET
				@Path("/E_alarmRegected")
				@Consumes(MediaType.TEXT_HTML)
				@Produces(MediaType.TEXT_HTML)
				public Response alarmRejectedE() throws IOException{
				System.out.println("We r in the service rejecting the alerts Earthquake");
				ConnectionFactory factory = new ConnectionFactory();
				com.rabbitmq.client.Connection connection = factory.newConnection();
			    Channel channel = connection.createChannel();
			   	factory.setHost("localhost");	
			   	factory.setUsername("guest");
			   	factory.setPassword("guest");
			   	channel.exchangeDeclare("REALWORLD", "fanout", true);
			   	String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
				String message = "<Event EventId= '1' Domain = 'OsmoseDemo' EventType = '24' Timestamp = '" + timeStamp + "' EventStatus = 'A' ItemId = '1' SubEventId = '2'></Event>";
			     channel.basicPublish("REALWORLD", "", null, message.getBytes());
			   	channel.close();
				return Response.status(200).build();
				}
			
			
	@GET
	@Path("/recieve")
	@Consumes(MediaType.TEXT_HTML)
	@Produces(MediaType.TEXT_HTML)
	public Response fwdCalcToCM() throws IOException{
	System.out.println("We r in the service forwarding the calc to context queue");
	String result = "para";
	int upper = 100;
	int lower = 10;
	int r = (int) (Math.random() * (upper - lower)) + lower;
    result = "ResultOfTheCalc= " + Integer.toString(r) + " ;";
    ConnectionFactory factory = new ConnectionFactory();
	com.rabbitmq.client.Connection connection = factory.newConnection();
    Channel channel = connection.createChannel();
   	factory.setHost("localhost");	
   	factory.setUsername("guest");
   	factory.setPassword("guest");
   	channel.exchangeDeclare("ContextManagerExchange", "direct", true);
   	String queueName = "TEST";
   	System.out.println("queueName= " + queueName);
  	channel.queueDeclare(queueName, false, false, false, null);
   	//channel.queueBind(queueName, "ContextManagerExchange", "");
    channel.basicPublish("", queueName, null, result.getBytes());
    //channel.basicPublish("", "ContextManagerExchange", null, result.getBytes());
   	channel.close();
	return Response.status(200).build();
	}
	
	 	 
	 /*@GET
     @Path("/form/{param}")
     @Produces(MediaType.APPLICATION_JSON)
     @Consumes(MediaType.APPLICATION_JSON)
     public Response getMsg(@PathParam("param") String urlparm) 
    		 throws IOException, InterruptedException, URISyntaxException {
		
		 System.out.println("invoked recieve data");
	
				 //JSONReadFromFile.return_CODE_JSONObj(new InputStreamReader(incomingData));
		 String result = "Jersey Data resource: " + urlparm;	
						
		 System.out.println(" WILDFLY............" + result);
		 
		
		 return Response.status(200).build();
	
	 }*/
	//This is a main thread to receive the data from the sensors. 
	//The data then published into the DB and into the ContextManagerExchange exchange
	
	 @GET
     @Path("/param")
     @Produces(MediaType.TEXT_HTML)
     @Consumes(MediaType.TEXT_HTML)
     public Response getParam(@QueryParam("temperature") String urlparm, 
    		 @QueryParam("pressure") String pressure, 
    		 @QueryParam("humidity") String humidity,
    		 @QueryParam("axelerometerXaxis") String axelerometerX,
    		 @QueryParam("axelerometerYaxis") String axelerometerY,
    		 @QueryParam("gas") String gas,
    		 @QueryParam("panic") String panic) 
    		 throws Exception {
		 String AxelerometerValueNew = null;
		 AxelerometerValueNew= axelerometerX + axelerometerY;
		 		 
		//System.out.println("With Rabbit Exchange....");
		String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
		String tempSim = null;
		if(urlparm!=null)
		 tempSim = urlparm;
		else
			tempSim = "0";
		String humSim = null;
		if(humidity!=null)
		humSim = humidity;
		else
			humSim="0";
		String presSim=null;
		if(pressure!=null)
		presSim=pressure;
		else
			presSim="0";
		
		String axelSimX=null;
		if(axelerometerX!=null)
		axelSimX=axelerometerX;
		else
			axelSimX = "0";	
		String axelSimY=null;
		if(axelerometerY!=null)
		axelSimY=axelerometerY;
		else
			axelSimY="0";
		String msg = "timestamp:" + timeStamp + ";temperature:" + urlparm + ";humidity:" + humidity + 
				";pressure:" + pressure + ";axelX:" + axelerometerX+ ";axelY:" + axelerometerY + ";gas:" + gas + ";panic:" + panic;
		//System.out.println(" T= " + tempSim + " Hum= " + humidity + " Pres = "  + presSim + " axelX = " + axelSimX);
		try {
			System.out.println("Data to put in DB" + timeStamp +urlparm +  pressure + axelerometerX + axelerometerY + humidity +gas + panic);
			InsertData insData = new InsertData();
			//System.out.println("Insert data in DB ...................");
			insData.insertDataBase(timeStamp, urlparm, pressure, axelSimX, axelSimY, humidity, gas, panic);
			
			insData.pushGFTAttribute(urlparm, pressure, axelSimX, axelSimY, humidity, gas, panic);
			//System.out.println(tempSim + " " + pressure + " " + axelSimX + " " + axelSimY + " "+ humidity+" " + gas + " "+ panic );
			//pushGFTAttribute(urlparm, pressure, axelSimX, axelSimY, humidity, gas, panic);
			//insertDataBase(timeStamp,urlparm, pressure,axelerometerX,axelerometerY,humidity,gas,panic);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//Creating the EXCHANGE to put the recieved values
		ConnectionFactory factory = new ConnectionFactory();
		com.rabbitmq.client.Connection connection = factory.newConnection();
	    Channel channel = connection.createChannel();
       	factory.setHost("localhost");	
       	factory.setUsername("guest");
       	factory.setPassword("guest");
       	channel.exchangeDeclare("ContextManagerExchange", "fanout", true);
       
        channel.basicPublish("ContextManagerExchange", "", null, msg.getBytes());
			String responseUnin = "g:start";
			
			 //System.out.println("Before: " + tempSimOld +":"+ urlparm + "_"+ humSimOld+":"+ humidity +"_"+presSimOld+":"+pressure+"_" + panicOld+":"+panic+"_"+AxelerometerValueNew+":"+AxelerometerValueOld);
			 Boolean axel = AxelerometerValueNew.equals(AxelerometerValueOld);
			 Boolean temper = urlparm.equals(tempSimOld);
			 Boolean hummi = humSim.equals(humSimOld);
			 Boolean pres = presSim.equals(presSimOld);
			 Boolean pan = panic.equals(panicOld);
			 System.out.println(axel + ";" + temper + ";"+ hummi + ";" + pres + ";" + pan);
			 
				
				 if (AxelerometerValueOld!=null&&!AxelerometerValueNew.equals(AxelerometerValueOld))
				{
					
					 responseUnin = "r:stop";
					//Adding the Earthqueke event to the exchange
					ConnectionFactory factoryRWEx = new ConnectionFactory();
					com.rabbitmq.client.Connection connectionRW = factoryRWEx.newConnection();
				    Channel channelRW = connectionRW.createChannel();
			       	factory.setHost("localhost");	
			       	factory.setUsername("guest");
			       	factory.setPassword("guest");
			       	channelRW.exchangeDeclare("REALWORLD", "fanout", true);
			       			
			       	String eventMsg = "<Event EventId= '1' Domain = 'Test' EventType = '2' Timestamp = '" + timeStamp + "' EventStatus = 'A' ItemId = '1' SubEventId = ''></Event>";
			       	channelRW.basicPublish("REALWORLD", "", null, eventMsg.getBytes());
			       	InsertData insData = new InsertData();
			    	
				
					//try {
						//Event pushed to the local DB and to the GFT DB
						insData.insertEvents(timeStamp, "2", "A", "test");
						insData.pushGFTEvents("2","A");
					/*} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}*/
										channelRW.close();
					System.out.println("RED!!!!!!!!!!!!!");
				}
				 else if (panic.equals("1")&&!panic.equals(panicOld) )
					{
					//Adding the Panic event to the exchange
						ConnectionFactory factoryRWEx = new ConnectionFactory();
						com.rabbitmq.client.Connection connectionRW = factoryRWEx.newConnection();
					    Channel channelRW = connectionRW.createChannel();
				       	factory.setHost("localhost");	
				       	factory.setUsername("guest");
				       	factory.setPassword("guest");
				       	channelRW.exchangeDeclare("REALWORLD", "fanout", true);
				       			
				       	String eventMsg = "<Event EventId= '2' Domain = 'Test' EventType = '4' Timestamp = '" + timeStamp + "' EventStatus = 'A' ItemId = '1' SubEventId = ''></Event>";
				       	channelRW.basicPublish("REALWORLD", "", null, eventMsg.getBytes());
				       	InsertData insData = new InsertData();
						try {
							insData.insertEvents(timeStamp, "4", "A", "test");
							insData.pushGFTEvents("4","A");
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
											channelRW.close();		
					 responseUnin= "y:pause";
							System.out.println("Yellow!!!!!!!!!!!!! " + eventMsg);
					}
				 
				 else if (AxelerometerValueNew.equals(AxelerometerValueOld)&&urlparm.equals(tempSimOld)&&humSim.equals(humSimOld)&&presSim.equals(presSimOld)&&panic.equals(panicOld))
				 {
					 
					 responseUnin = "g:none"; 
				 }
				  if(Integer.valueOf(urlparm) > 45)
				 {
					//Adding the Hight Temperature event to the exchange
						ConnectionFactory factoryRWEx = new ConnectionFactory();
						com.rabbitmq.client.Connection connectionRW = factoryRWEx.newConnection();
					    Channel channelRW = connectionRW.createChannel();
				       	factory.setHost("localhost");	
				       	factory.setUsername("guest");
				       	factory.setPassword("guest");
				       	channelRW.exchangeDeclare("REALWORLD", "fanout", true);
				       			
				       	String eventMsg = "<Event EventId= '2' Domain = 'Test' EventType = '18' Timestamp = '" + timeStamp + "' EventStatus = 'A' ItemId = '1' SubEventId = ''></Event>";
				       	channelRW.basicPublish("REALWORLD", "", null, eventMsg.getBytes());
				       	InsertData insData = new InsertData();
						try {
							insData.insertEvents(timeStamp, "18", "A", "test");
							insData.pushGFTEvents("18","A");
							System.out.println("Event to be sent to REALWORLD = " + eventMsg);
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
											channelRW.close();		
					 
				 }
				  if(Integer.valueOf(gas) < 1000)
					 {
						//Adding the Gas event to the exchange
							ConnectionFactory factoryRWEx = new ConnectionFactory();
							com.rabbitmq.client.Connection connectionRW = factoryRWEx.newConnection();
						    Channel channelRW = connectionRW.createChannel();
					       	factory.setHost("localhost");	
					       	factory.setUsername("guest");
					       	factory.setPassword("guest");
					       	channelRW.exchangeDeclare("REALWORLD", "fanout", true);
					       			
					       	String eventMsg = "<Event EventId= '2' Domain = 'Test' EventType = '19' Timestamp = '" + timeStamp + "' EventStatus = 'A' ItemId = '1' SubEventId = ''></Event>";
					       	channelRW.basicPublish("REALWORLD", "", null, eventMsg.getBytes());
					       	InsertData insData = new InsertData();
							try {
								insData.insertEvents(timeStamp, "19", "A", "test");
								insData.pushGFTEvents("19","A");
							} catch (Exception e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
												channelRW.close();		
						 
					 }
				  				
				
				 System.out.println("After:" + tempSimOld +":"+ urlparm + "_"+ humSimOld+":"+ humSim +"_"+presSimOld+":"+presSim+"_" + panicOld+":"+panic+"_"+AxelerometerValueNew+":"+AxelerometerValueOld);
						
				 AxelerometerValueOld = axelerometerX + axelerometerY;
						 tempSimOld = urlparm;
						 humSimOld = humSim;
						 presSimOld = presSim;
						 panicOld = panic;
						 channel.close();
		return Response.status(200).entity(responseUnin).build();
	
	 }
	 
	 @GET
     @Path("/paramold")
     @Produces(MediaType.APPLICATION_JSON)
     @Consumes(MediaType.APPLICATION_JSON)
     public Response getParamOld(@QueryParam("temperature") String urlparm, 
    		 @QueryParam("pressure") String pressure, 
    		 @QueryParam("humidity") String humidity,
    		 @QueryParam("axelerometerXaxis") String axelerometerX,
    		 @QueryParam("axelerometerYaxis") String axelerometerY,
    		 @QueryParam("gas") String gas,
    		 @QueryParam("panic") String panic) 
    		 throws IOException, InterruptedException, URISyntaxException {
		
		System.out.println("With Rabbit Exchange....");
		String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
		String tempSim = urlparm;
		String hunSim = humidity;
		String presSim=pressure;
		String axelSimX=axelerometerX;
		String axelSimY=axelerometerY;
		String msg = "timestamp:" + timeStamp + ";temperature:" + urlparm + ";humidity:" + humidity + 
				";pressure:" + pressure + ";axelX:" + axelerometerX+ ";axelY:" + axelerometerY + ";gas:" + gas + ";panic:" + panic;
		System.out.println(" T= " + tempSim + " Hum= " + humidity + " Pres = "  + presSim + " axelX = " + axelSimX);
		try {
			System.out.println("Data to put in DB" + timeStamp +urlparm +  pressure + axelerometerX + axelerometerY + humidity +gas + panic);
			InsertData insData = new InsertData();
			insData.insertDataBase(timeStamp, urlparm, pressure, axelSimX, axelSimY, humidity, gas, panic);
			//insertDataBase(timeStamp,urlparm, pressure,axelerometerX,axelerometerY,humidity,gas,panic);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//Creating the EXCHANGE to put the recieved values
		ConnectionFactory factory = new ConnectionFactory();
		com.rabbitmq.client.Connection connection = factory.newConnection();
	    Channel channel = connection.createChannel();
       	factory.setHost("localhost");	
       	factory.setUsername("guest");
       	factory.setPassword("guest");
       	channel.exchangeDeclare("SIMUL_DATA", "direct", true);
       	String queueName = channel.queueDeclare().getQueue();
       	channel.queueBind(queueName, "SIMUL_DATA", "");
        channel.basicPublish("", "SIMUL_DATA", null, msg.getBytes());
		channel.close();
		return Response.status(200).entity(msg).build();
	
	 }
	
	 public static String pass(String message){
			//String Internalmessage = null;
			System.out.println("message from the queue = " + message);
			messageinQueue = message;
				return message;
			}
	
}
