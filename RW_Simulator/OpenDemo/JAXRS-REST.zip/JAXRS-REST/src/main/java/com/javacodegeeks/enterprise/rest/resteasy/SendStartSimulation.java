package com.javacodegeeks.enterprise.rest.resteasy;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;


	public class SendStartSimulation {
		
		private final static String QUEUE_NAME = "MonitoringQueue";
		
		
		public static void main(String[] argv)
	                  throws Exception {
			//Timer timer = new Timer();
			//timer.schedule(new SayHello(), 0, 10000);
	
	    	}
		public static void OverheatingConfirmedMsg() throws IOException
		{
			
			ConnectionFactory factory = new ConnectionFactory();
		    Connection connection = factory.newConnection();
		    factory.setHost("localhost");
		    Channel channel = connection.createChannel();
			channel.exchangeDeclare("REALWORLD","fanout", true);
			  
	       	String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
	    	String message = "<Event EventId= '1' Domain = 'OsmoseDemo' EventType = '3' Timestamp = '" + timeStamp + "' EventStatus = 'A' ItemId = '1' SubEventId = '18'></Event>";
	        	
	    	channel.basicPublish("REALWORLD","" , null, message.getBytes());
	        System.out.println(" [x] Sent '" + message);
	        channel.close();
			
		}
		
		static class SayHello extends TimerTask {
		    public void run() {
		    	ConnectionFactory factory = new ConnectionFactory();
			    Connection connection = null;
				try {
					connection = factory.newConnection();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			    Channel channel = null;
			    Channel channelVW = null;
				try {
					channel = connection.createChannel();
					channelVW = connection.createChannel();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			    factory.setHost("localhost");	
		       	factory.setUsername("guest");
		       	factory.setPassword("guest");
		       	try {
					channel.exchangeDeclare("ContextManagerExchange", "fanout", true);
					channelVW.exchangeDeclare("VIRTUALWORLD","fanout", true);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
		       	try {
					channel.queueDeclare("MonitoringQueue", false, false, false, null);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
		       			  
		       	String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
		        String message = "<Event EventId= '1' Domain = 'Test' EventTypeId = '16' Timestamp = '" + timeStamp + "' EventStatus = 'A' ItemId = '1' SubEventId =''></Event>";
		        String messageVW = "<Event EventId= '12' Domain = 'Test' EventTypeId = '5' Timestamp = '" + timeStamp + "' EventStatus = 'A' ItemId = '1' SubEventId =''></Event>";
			       
		        try {
		        	channel.queueBind("MonitoringQueue", "ContextManagerExchange", "");
		        	channel.basicPublish("ContextManagerExchange","MonitoringQueue", null, message.getBytes());
		        	channelVW.basicPublish("VIRTUALWORLD","",null,messageVW.getBytes());
					channel.close();
				    //connection.close();
					//String queueName = channel.queueDeclare().getQueue();
					//System.out.println("Hello World!  " + queueName); 
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					
				}
		      	       
		       
		    }
		}

	}
	


