package com.javacodegeeks.enterprise.rest.resteasy;


import java.io.FileWriter;
import java.io.IOException;

import java.net.URISyntaxException;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

@Path("/rest")
public class RESTEasyService {
	final ExecutorService exService = Executors.newSingleThreadExecutor();
	//Test GET service just to see it up and running 
	@GET
	@Path("/test")
	@Consumes(MediaType.TEXT_HTML)
	@Produces(MediaType.TEXT_HTML)
	public Response testService(){
	System.out.println("We r in the test bla-bla service. New param test!!!!!!!!!");
	return Response.status(200).build();
	}
	 	 
	 @GET
     @Path("/form/{param}")
     @Produces(MediaType.APPLICATION_JSON)
     @Consumes(MediaType.APPLICATION_JSON)
     public Response getMsg(@PathParam("param") String urlparm) 
    		 throws IOException, InterruptedException, URISyntaxException {
		
		 System.out.println("invoked recieve data");
	
				 //JSONReadFromFile.return_CODE_JSONObj(new InputStreamReader(incomingData));
		 String result = "Jersey Data resource: " + urlparm;	
						
		 System.out.println(" WILDFLY............" + result);
		 
		
		 return Response.status(200).build();
	
	 }
	 @GET
     @Path("/param")
     @Produces(MediaType.APPLICATION_JSON)
     @Consumes(MediaType.APPLICATION_JSON)
     public Response getParam(@QueryParam("temperature") String urlparm, 
    		 @QueryParam("pressure") String pressure, 
    		 @QueryParam("humidity") String humidity,
    		 @QueryParam("axelerometerXaxis") String axelerometerX,
    		 @QueryParam("axelerometerYaxis") String axelerometerY,
    		 @QueryParam("gas") String gas,
    		 @QueryParam("panic") String panic) 
    		 throws IOException, InterruptedException, URISyntaxException {
		
		System.out.println("With Rabbit Exchange....");
		String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
		String tempSim = urlparm;
		String hunSim = humidity;
		String presSim=pressure;
		String axelSimX=axelerometerX;
		String axelSimY=axelerometerY;
		String msg = "timestamp:" + timeStamp + ";temperature:" + urlparm + ";humidity:" + humidity + 
				";pressure:" + pressure + ";axelX:" + axelerometerX+ ";axelY:" + axelerometerY + ";gas:" + gas + ";panic:" + panic;
		System.out.println(" T= " + tempSim + " Hum= " + humidity + " Pres = "  + presSim + " axelX = " + axelSimX);
		
		//Creating the EXCHANGE to put the recieved values
		ConnectionFactory factory = new ConnectionFactory();
	    Connection connection = factory.newConnection();
	    Channel channel = connection.createChannel();
       	factory.setHost("localhost");	
       	factory.setUsername("guest");
       	factory.setPassword("guest");
       	channel.exchangeDeclare("SIMUL_DATA", "direct", true);
       	String queueName = channel.queueDeclare().getQueue();
       	channel.queueBind(queueName, "SIMUL_DATA", "");
        channel.basicPublish("", "SIMUL_DATA", null, msg.getBytes());
		channel.close();
		return Response.status(200).entity(msg).build();
	
	 }
	
	 
	 	 
	 public static void CODE_JSONparser(JSONObject obj) throws IOException
	 {
		JSONArray features = (JSONArray) obj.get("generatedCodeArtifacts");
		Iterator<Object> iterator = features.iterator();
			
		while (iterator.hasNext()) {
			JSONObject jsonObjectNew = (JSONObject)iterator.next();
			String fileName = (String) jsonObjectNew.get("name");
			String fileContent = (String) jsonObjectNew.get("content");
			
			//FileWriter file = new FileWriter("/home/input/" + fileName);
			FileWriter file = new FileWriter("/home/osmose/input/" + fileName);
			file.write(fileContent);
			file.close();
			System.out.println("Successfully Copied JSON Object to File: " + fileName);
			System.out.println("Successfully Copied JSON Object to File Content: \n" + fileContent);
		}
	}
	
	
}
