package com.javacodegeeks.enterprise.rest.resteasy;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;



	public class SendSimple {
		private final static String QUEUE_NAME = "DIGITALWORLD";
		
		public static void main(String[] argv)
	                  throws Exception {
	    	
			int upper = 100;
			int lower = 10;
			ConnectionFactory factory = new ConnectionFactory();
		    Connection connection = factory.newConnection();
		    Channel channel = connection.createChannel();
	       	factory.setHost("localhost");
	       	channel.queueDeclare(QUEUE_NAME, false, false, false, null);
	       //infinite cycle to generate the random number in the queue
	       	while(true){
	       		try{
	       	int r = (int) (Math.random() * (upper - lower)) + lower;
	        String message = Integer.toString(r);
	        channel.basicPublish("", QUEUE_NAME, null, message.getBytes());
	        System.out.println(" [x] Sent '" + message + "'" + "" + "random number ");
	        Thread.sleep(1000);
	       	}catch(Exception e)
	       	{
	       	   System.out.println("Exception caught");
	       	}
	        
	    	}
	       	//channel.close();
	        
	        //connection.close();
	    }

	}


